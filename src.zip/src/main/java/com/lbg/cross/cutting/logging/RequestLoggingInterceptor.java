package com.lbg.cross.cutting.logging;

import java.util.logging.Level;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * Log every request received and handle headers
 */
@Flogger
@Component
@RequiredArgsConstructor
public class RequestLoggingInterceptor implements HandlerInterceptor {

    private static final String LOG_HEADER_STR = "Header: %s: %s";
    private final RequestHeaderValidator requestHeaderValidator;
    private final LoggingConfig loggingConfig;

    @Value("${api.public-api-path}")
    private String apiPublicBaseUrl;

    @Override
    public boolean preHandle(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response, @NonNull Object handler) {
        if (handler instanceof HandlerMethod) {
            log.atInfo().log(
                "Received Request: %s %s", request.getMethod(), request.getRequestURI());
            if (request.getRequestURI().matches(loggingConfig.getRequestsPattern())) {
               //Apply validation here or next steps here
                log.at(Level.INFO).log("Processing Request for matching endpoints in Request logging interceptor");
            }else {
                log.at(Level.INFO).log("Processing Request for Not matching endpoints in Request logging interceptor");
            }
        }
        return true;
    }

    @Override
    public void afterCompletion(@NonNull HttpServletRequest request,@NonNull HttpServletResponse response,@NonNull Object handler,
        Exception ex) {
        if (handler instanceof HandlerMethod) {
            log.atInfo().log(
                "Returning Response: %s for Request: %s %s",
                response.getStatus(), request.getMethod(), request.getRequestURI());
        }
    }

}

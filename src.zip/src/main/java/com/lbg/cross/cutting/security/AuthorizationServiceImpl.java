package com.lbg.cross.cutting.security;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.cross.cutting.config.AuthorizationServerConfig;
import com.lbg.cross.cutting.security.constants.AuthorizationConstants;
import com.lbg.cross.cutting.security.model.TokenRequest;
import com.lbg.cross.cutting.security.model.TokenResponse;
import java.io.IOException;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.Base64Utils;
import org.springframework.web.client.RestTemplate;

@Component("AuthorizationService")
@Flogger
public class AuthorizationServiceImpl implements AuthorizationService {


    private final AuthorizationServerConfig authorizationServerConfig;
    private final RestTemplate restTemplate;

    @Autowired
    public AuthorizationServiceImpl(AuthorizationServerConfig authorizationServerConfig, RestTemplate restTemplate) {
        this.authorizationServerConfig = authorizationServerConfig;
        this.restTemplate = restTemplate;
    }

    @Override
    public TokenResponse generateToken(String accessToken) {
        log.atInfo().log("Generate JWT token");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        TokenRequest tokenRequest = TokenRequest.builder()
                .tokenId(accessToken)
                .journeyType(authorizationServerConfig.getJourneyType())
                .expiryOffsetInSeconds(authorizationServerConfig.getTokenValidity())
                .build();
        HttpEntity<TokenRequest> entity = new HttpEntity<>(tokenRequest, headers);

        ResponseEntity<TokenResponse> response = restTemplate.postForEntity(
                authorizationServerConfig.getServerUrl() + AuthorizationConstants.JWT_GENERATE_ENDPOINT.getValue(), entity, TokenResponse.class);
        return response.getBody();
    }

    @Override
    public boolean isTokenValid(String accessToken) {
        log.atInfo().log("Request to authorisation server to validate a token");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.setBearerAuth(accessToken);
        headers.set("encrypted", "true");
        HttpEntity<TokenRequest> entity = new HttpEntity<>(headers);
        if(Boolean.parseBoolean(authorizationServerConfig.getSkipServiceCall())){
            log.atInfo().log("Authorisation Server call skipped");
            return true;
        }else {
            ResponseEntity<TokenResponse> response = restTemplate.exchange(
                authorizationServerConfig.getServerUrl()
                    + authorizationServerConfig.getVerificationEndpoint(), HttpMethod.GET,
                entity, TokenResponse.class);

            log.atInfo().log("Authorisation Server Returned: %s", response.getStatusCode());
            if (response.getStatusCode() != HttpStatus.OK) {
                return false;
            }
            return Objects.requireNonNull(response.getBody()).getValidated();
        }
    }

    @Override
    public Map<String, Object> retrieveTokenDetails(String token) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        String payload = token.substring(token.indexOf('.') + 1, token.lastIndexOf('.'));
        return mapper.readValue(Base64Utils.decodeFromString(payload), new TypeReference<>() {
        });
    }

    @Override
    public TokenResponse retrieveAccessToken(String bearerToken) {
        log.atInfo().log("Request to crypto server to retrieve access token from bearer token");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.setBearerAuth(bearerToken);
        headers.add("encrypted", "true");
        HttpEntity<TokenRequest> entity = new HttpEntity<>(headers);
    //FIXME: should be update to actual auth server after deployment
        if(Boolean.parseBoolean(authorizationServerConfig.getSkipServiceCall())){
            TokenResponse tokenResponse = new TokenResponse();
            tokenResponse.setToken("toke");
            tokenResponse.setValidated(true);
            TokenRequest tokenRequest = new TokenRequest();
            tokenRequest.setTokenId("TokenId");
            tokenRequest.setJourneyType("Testing-boiler-plate");
            tokenResponse.setTokenRequest(tokenRequest);
            return tokenResponse;
        }else{
            ResponseEntity<TokenResponse> response = restTemplate.exchange(
                authorizationServerConfig.getServerUrl() + authorizationServerConfig.getRetrieveTokenEndpoint(), HttpMethod.GET,
                entity, TokenResponse.class);

            if(response.getStatusCode() != HttpStatus.OK) {
                return null;
            }
            return response.getBody();
        }

    }
}

package com.lbg.cross.cutting.constants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ApiHeader {
    AUTHORIZATION("Authorization", "authorization", false, false, "Bearer Token", null, new ArrayList<>()),
    CORRELATION_ID("X-Correlation-ID", "x-correlation-id", false, true, "Unique ID to correlate requests", null, new ArrayList<>()),;

    private final String headerName;
    private final String headerKey;
    private final boolean isRequired;
    private final boolean isVisible;
    private final String description;
    private final String defaultOption;
    private final List<String> options;

    public static Optional<ApiHeader> valueOfLabel(String label) {
        ApiHeader value = null;
        for (ApiHeader e : values()) {
            if (e.getHeaderName().equalsIgnoreCase(label)) {
                value = e;
                break;
            }
        }
        return Optional.ofNullable(value);
    }
}

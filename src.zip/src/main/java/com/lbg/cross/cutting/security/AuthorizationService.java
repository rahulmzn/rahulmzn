package com.lbg.cross.cutting.security;

import com.lbg.cross.cutting.security.model.TokenResponse;

import java.io.IOException;
import java.util.Map;

public interface AuthorizationService {

    /**
     * This method generate JWT token and create Cookie
     *
     * @param accessToken : access token for authorisation
     * @return Cookie
     */
    TokenResponse generateToken(String accessToken);
    boolean isTokenValid(String token);
    Map<String, Object> retrieveTokenDetails(String token) throws IOException;
    TokenResponse retrieveAccessToken(String bearerToken);

}

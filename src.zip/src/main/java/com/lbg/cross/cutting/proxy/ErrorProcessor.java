package com.lbg.cross.cutting.proxy;

import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;

public interface ErrorProcessor<T, R> {

    boolean isApplicable(T response, HttpStatus httpStatus);
    Mono<R> processError(T response, HttpStatus httpStatus) ;

}

package com.lbg.cross.cutting.exception;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.WebClientException;

/**
 * Unchecked Service Exceptions
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ServiceException extends RuntimeException {

    public static class BadInput extends RuntimeException {
        public BadInput(String message) {
            super(message);
        }
    }

    public static class InvalidHeaders extends RuntimeException {
        public InvalidHeaders(String message) {
            super(message);
        }
    }

    public static class NoData extends RuntimeException {
        public NoData(String message) {
            super(message);
        }
    }

    public static class ServerError extends RuntimeException {
        public ServerError(String message) {
            super(message);
        }
    }

    public static class ClientError extends RuntimeException {
        public ClientError(String message) {
            super(message);
        }
    }

    public static class WebClientError extends WebClientException {
        private final ErrorResponse errorResponse;
        private final HttpStatus httpStatus;

        public WebClientError(ErrorResponse errorResponse, HttpStatus httpStatus) {
            super("Web Client Error");
            this.errorResponse = errorResponse;
            this.httpStatus = httpStatus;
        }

        public WebClientError(String message, HttpStatus httpStatus) {
            super(message);
            this.errorResponse = null;
            this.httpStatus = httpStatus;
        }

        public HttpStatus getHttpStatus() {
            return httpStatus;
        }

        public ErrorResponse getErrorResponse() {
            return errorResponse;
        }
    }
}

package com.lbg.cross.cutting.util;

import com.lbg.cross.cutting.constants.ApiHeader;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Objects;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class HeaderUtil {

    public static String getRequestHeader(String headerName) {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();

        if (Objects.nonNull(attributes)) {
            return attributes.getRequest().getHeader(headerName);

        }
        return null;
    }

    public static String getCorrelationIdFromHeader(final HttpServletRequest request) {
        String correlationId = request.getHeader(ApiHeader.CORRELATION_ID.getHeaderKey());
        if (!StringUtils.hasText(correlationId)) {
            correlationId = generateUniqueCorrelationId();
        }
        return correlationId;
    }

    private static String generateUniqueCorrelationId() {
        return UUID.randomUUID().toString();
    }

}

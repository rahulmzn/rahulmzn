package com.lbg.cross.cutting.exception;

import java.io.Serializable;
import java.util.Objects;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * Standard error for all services
 */
@NoArgsConstructor
@Getter
public class Error implements Serializable {

    private static final long serialVersionUID = 1L;

    private String reasonCode;
    private String message;

    public Error(String reasonCode, String message){
        this.reasonCode=reasonCode;
        this.message=message;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Error error = (Error) o;
        return reasonCode.equals(error.reasonCode) && message.equals(error.message);
    }

    @Override
    public int hashCode() {
        return Objects.hash(reasonCode, message);
    }
}

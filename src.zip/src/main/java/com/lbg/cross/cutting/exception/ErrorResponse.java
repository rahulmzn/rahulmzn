package com.lbg.cross.cutting.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lbg.cross.cutting.constants.ApiHeader;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.slf4j.MDC;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * Standard Error response containing one or more errors for all services
 */
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
public class ErrorResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * id is an optional filed can be used when required for example return correlation id
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String id;

    @Setter
    private Set<Error> errors = new HashSet<>();

    public ErrorResponse(String id, Set<Error> errors) {
        this.errors = errors;
        this.id = id;
    }

    public ErrorResponse(Set<Error> errors) {
        this.errors = errors;
    }

    public boolean addError(Error error) {
        this.id= MDC.getMDCAdapter().get(ApiHeader.CORRELATION_ID.name());
        return errors.add(error);
    }
}

package com.lbg.cross.cutting.security.filters;

import static com.lbg.cross.cutting.security.constants.AuthorizationConstants.UNKNOWN;
import static com.lbg.cross.cutting.util.AuthUtil.getAccessTokenFromRequest;
import static com.lbg.cross.cutting.util.AuthUtil.retrieveJWTToken;
import static com.lbg.cross.cutting.util.HeaderUtil.getCorrelationIdFromHeader;

import com.lbg.cross.cutting.constants.ApiHeader;
import com.lbg.cross.cutting.security.AuthorizationService;
import com.lbg.cross.cutting.security.constants.AuthorizationConstants;
import com.lbg.cross.cutting.security.model.TokenResponse;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.servlet.FilterChain;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.slf4j.MDC;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

@RequiredArgsConstructor
@Component
@Flogger
public class AuthorizationFilter extends OncePerRequestFilter {

    private static final List<String> EXCLUSION_LIST = Arrays.asList("/url", "/tokens");

    private final ServletContext servletContext;
    private final AuthorizationService jwtService;


    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response,
        @NonNull FilterChain filterChain) throws ServletException, IOException {
        String contextPath = this.servletContext.getContextPath();

        List<String> exclusionList = EXCLUSION_LIST.stream().map(contextPath::concat).collect(Collectors.toList());

        if (!exclusionList.contains(request.getRequestURI())) {
            String token = getAccessTokenFromRequest(request);
            if (Objects.isNull(token)) {
                log.atInfo().log("Token is not present in the request");
                filterChain.doFilter(request, response);
                return;
            }
            log.atInfo().log("Token has been found in the request and processing for authentication");
            UsernamePasswordAuthenticationToken authentication = getAuthentication(token);
            if(Objects.isNull(authentication)){
                log.atInfo().log("token authentication un-successful");
            }else {
                SecurityContextHolder.getContext().setAuthentication(authentication);
                log.atInfo().log("token validation successful");
            }
        }
        final String correlationId = getCorrelationIdFromHeader(request);
        MDC.put(ApiHeader.CORRELATION_ID.getHeaderKey(), correlationId);
        final String ipAddress = getClientIp(request);
        MDC.put(AuthorizationConstants.IP_ADDRESS.getValue(), ipAddress);

        filterChain.doFilter(request, response);
    }

    private UsernamePasswordAuthenticationToken getAuthentication(String bearerToken) {
        log.atInfo().log("Checking authorisation");
        try {
            String token = retrieveJWTToken(bearerToken);
            // validate the token
            if (jwtService.isTokenValid(token)) {
                TokenResponse tokenResponse = jwtService.retrieveAccessToken(token);
                if (tokenResponse != null) {
                    return new UsernamePasswordAuthenticationToken(tokenResponse.getTokenRequest().getTokenId(), null,
                        Collections.singleton(new SimpleGrantedAuthority(tokenResponse.getTokenRequest().getJourneyType())));
                }
            }
        } catch (Exception ex) {
            log.atInfo().log("The request is not authorized %s", ex);
        }
        return null;
    }


    public String getClientIp(HttpServletRequest request) {
        String ipAddress = request.getHeader("X-Forwarded-For");
        if (!StringUtils.hasText(ipAddress) || UNKNOWN.getValue().equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader("Proxy-Client-IP");
        }

        if (!StringUtils.hasText(ipAddress) || UNKNOWN.getValue().equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader("WL-Proxy-Client-IP");
        }

        if (!StringUtils.hasText(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
            if (AuthorizationConstants.LOCALHOST_IPV4.getValue().equals(ipAddress) || AuthorizationConstants.LOCALHOST_IPV6.getValue().equals(ipAddress)) {
                try {
                    InetAddress inetAddress = InetAddress.getLocalHost();
                    ipAddress = inetAddress.getHostAddress();
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                }
            }
        }

        if (StringUtils.hasText(ipAddress)
            && ipAddress.length() > 15
            && ipAddress.indexOf(",") > 0) {
            ipAddress = ipAddress.substring(0, ipAddress.indexOf(","));
        }

        return ipAddress;
    }

}

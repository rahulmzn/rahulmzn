package com.lbg.cross.cutting.logging;

import com.lbg.cross.cutting.constants.ApiHeader;
import com.lbg.cross.cutting.exception.ServiceException.InvalidHeaders;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.flogger.Flogger;
import org.springframework.stereotype.Component;

@Component
@Flogger
public class RequestHeaderValidator {

    /**
     * Validates request for invalid or missing headers
     *
     * @param headersInfo Request headers key-value map
     */
    public boolean validate(Map<String, String> headersInfo) {

        log.atInfo().log("Validating Request Headers: %s", String.join(", ", headersInfo.keySet()));

        var errors = new ArrayList<String>();

        List<String> missingMandatoryHeaders = checkMandatoryHeaders(headersInfo);
        if (!missingMandatoryHeaders.isEmpty()) {
            errors.add("Mandatory Request Headers missing: " + String.join(", ", missingMandatoryHeaders));
        }

        List<String> invalidValueHeaders = checkInvalidHeaders(headersInfo);
        if (!invalidValueHeaders.isEmpty()) {
            errors.add("Invalid Request Header values: " + String.join(", ", invalidValueHeaders));
        }

        if (!errors.isEmpty()) {
            throw new InvalidHeaders(String.join(". ", errors));
        }

        log.atFine().log("Header validation successful");
        return true;
    }

    private List<String> checkMandatoryHeaders(Map<String, String> headersInfo) {

        return Arrays.stream(ApiHeader.values())
            .filter(e -> e.isRequired() && !headersInfo.containsKey(e.getHeaderName().toLowerCase()))
            .map(ApiHeader::getHeaderName)
            .collect(Collectors.toList());
    }

    private List<String> checkInvalidHeaders(Map<String, String> headersInfo) {

        return headersInfo.keySet().stream()
            .filter(s -> {
                var apiHeaderOptional = ApiHeader.valueOfLabel(s);
                return apiHeaderOptional.isPresent();
            })
            .map(s -> checkHeaderValue(ApiHeader.valueOfLabel(s).get(), s))
            .flatMap(Optional::stream)
            .collect(Collectors.toList());
    }

    private Optional<String> checkHeaderValue(ApiHeader apiHeader, String headerName) {
        String invalidHeaderValue = null;
    if (apiHeader.isRequired()) {
                invalidHeaderValue = headerName;
            }
        return Optional.ofNullable(invalidHeaderValue);
    }
}

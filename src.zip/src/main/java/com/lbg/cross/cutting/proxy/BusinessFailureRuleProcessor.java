package com.lbg.cross.cutting.proxy;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.web.reactive.function.client.ClientResponse;

import java.util.List;

/**
 * Error Mapper for payments endpoint for Checkout
 */
public interface BusinessFailureRuleProcessor extends ErrorProcessor<JsonNode, ClientResponse> {

}

package com.lbg.cross.cutting.security.constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public enum AuthorizationConstants {
    JWT_COOKIE_NAME("JRNTOKEN"),
    AUTH_BEARER("Bearer "),
    LOCALHOST_IPV4("127.0.0.1"),
    LOCALHOST_IPV6("0:0:0:0:0:0:0:1"),
    JWT_VERIFICATION_ENDPOINT("/token/verify"),
    JWT_GENERATE_ENDPOINT("/token/encrypt/sign"),
    JWT_RETRIEVE_ENDPOINT("/token/retrieveAccessToken"),
    SPACE_AS_STRING(" "),
    UNKNOWN("unknown"),
    JWT_BODY_FILTER_USER_ROLE("userRole"),
    JWT_BODY_FILTER_USER_ID("userId"),
    IP_ADDRESS("ipAddress");

    private String value;
}

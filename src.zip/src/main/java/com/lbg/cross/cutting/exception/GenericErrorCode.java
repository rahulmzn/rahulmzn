package com.lbg.cross.cutting.exception;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum GenericErrorCode {
    MISSING_HEADER_ERROR_CODE("missing.header.error.code"),
    MISSING_BODY_ERROR_CODE("missing.body.error.code"),
    INVALID_HEADER_ERROR_CODE("invalid.header.error.code"),
    INVALID_BODY_ERROR_CODE("invalid.body.error.code"),
    INTERNAL_ERROR("unexpected.error"),

    SERVICE_ERROR("Unmapped Error Code"),
    MISSING_QUERY_PARAMETER_ERROR_CODE("missing.query.parameter.error.code");

    private final String value;
}

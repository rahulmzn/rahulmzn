package com.lbg.cross.cutting.security.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.util.Date;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TokenResponse {
    private String token;
    private Boolean validated;
    private TokenRequest tokenRequest;
    private Date expiration;
    private Date issuedAt;
    private String accessTokenFromClaims;

    public TokenResponse(String token, Boolean validated) {
        this.token = token;
        this.validated = validated;
        this.tokenRequest = null;
        this.expiration = null;
        this.issuedAt = null;
        this.accessTokenFromClaims=null;
    }
}

package com.lbg.cross.cutting.constants;


import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ApplicationInfo {

    public final static String APP_CODE="LBG_" ;
}

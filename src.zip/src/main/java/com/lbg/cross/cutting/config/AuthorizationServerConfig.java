package com.lbg.cross.cutting.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "jwt")
@Setter
@Getter
public class AuthorizationServerConfig {

    private String skipServiceCall;
    private String serverUrl;
    private String verificationEndpoint;
    private String retrieveTokenEndpoint;
    private Integer tokenValidity;
    private String journeyType;

}

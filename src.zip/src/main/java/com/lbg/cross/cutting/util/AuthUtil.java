package com.lbg.cross.cutting.util;

import com.lbg.cross.cutting.constants.ApiHeader;
import com.lbg.cross.cutting.security.constants.AuthorizationConstants;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import org.springframework.web.util.WebUtils;

@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class AuthUtil {

    public static String retrieveJWTToken(String bearerToken) {
        String[] parts = bearerToken.split(AuthorizationConstants.SPACE_AS_STRING.getValue());
        String token = bearerToken;
        if (parts.length == 2) {
            token = parts[1];
        }
        return token;
    }

    public static String getAccessTokenFromRequest(HttpServletRequest req) {
        String header = req.getHeader(ApiHeader.AUTHORIZATION.getHeaderName());
        if (header != null && header.startsWith(AuthorizationConstants.AUTH_BEARER.getValue())) {
            return header.substring(7);
        }
        Cookie secureCookie = WebUtils.getCookie(req, AuthorizationConstants.JWT_COOKIE_NAME.getValue());
        return secureCookie != null ? secureCookie.getValue() : null;
    }
}

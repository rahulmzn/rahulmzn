package com.lbg.cross.cutting.security.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRawValue;
import lombok.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TokenRequest {

    private String tokenId;
    private String journeyType;
    @JsonRawValue
    private String appData;
    private int expiryOffsetInSeconds;
    private Boolean checkThreshold;

}

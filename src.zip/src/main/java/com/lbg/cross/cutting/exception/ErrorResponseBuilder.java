package com.lbg.cross.cutting.exception;

import static com.lbg.cross.cutting.constants.ApplicationInfo.APP_CODE;

import java.util.List;
import lombok.Getter;
import lombok.extern.flogger.Flogger;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.FieldError;
import org.springframework.web.context.annotation.RequestScope;

/**
 * Builds error by looking up error code within resource bundle
 */
@Component
@RequestScope
@Flogger
public class ErrorResponseBuilder {

    private final MessageSource messageSource;
    @Getter
    private final ErrorResponse errorResponse = new ErrorResponse();
    private final List<String> missingFieldErrorList = List.of("NotBlank", "NotEmpty", "NotNull");

    public ErrorResponseBuilder(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    /**
     * Add error by looking up the messages.properties file for specified Service Error Code or
     * field name
     */
    public ErrorResponse addError(String fieldOrErrorCode) {
        if (fieldOrErrorCode.startsWith(APP_CODE)) {
            errorResponse.addError(new Error(fieldOrErrorCode, getErrorMessage(fieldOrErrorCode)));
            return errorResponse;
        }
        return addGenericError(GenericErrorCode.INVALID_BODY_ERROR_CODE.getValue(),
            fieldOrErrorCode);
    }

    /**
     * Add error by looking up the messages.properties or as specified
     */
    public ErrorResponse addError(String errorCode, String errorMsg) {
        if (errorCode.startsWith(APP_CODE)) {
            errorMsg = getErrorMessage(errorCode);
        }
        errorResponse.addError(new Error(errorCode, errorMsg));
        return errorResponse;
    }

    /**
     * Add error for specified field in error
     */
    public ErrorResponse addError(FieldError error) {
        String errorField = error.getField();
        String defaultMessage = getErrorMessage(error.getDefaultMessage());

        if (StringUtils.hasText(defaultMessage)) {
            errorResponse.addError(new Error(error.getDefaultMessage(), defaultMessage));
        } else {
            String commonErrorCode;
            if (missingFieldErrorList.contains(error.getCode())) {
                commonErrorCode = GenericErrorCode.MISSING_BODY_ERROR_CODE.getValue();
            } else {
                commonErrorCode = GenericErrorCode.INVALID_BODY_ERROR_CODE.getValue();
            }
            String errorCode = getErrorMessage(commonErrorCode);
            String errorMsg = getErrorMessage(errorCode);
            errorResponse.addError(new Error(errorCode, String.format(errorMsg, errorField)));
        }
        return errorResponse;
    }

    /**
     * Add generic error for (optional) field in error
     */
    public ErrorResponse addGenericError(String genericErrorCode, String fieldName) {
        String errorCode = getErrorMessage(genericErrorCode);
        String errorMsg = getErrorMessage(errorCode);
        errorResponse.addError(new Error(errorCode, String.format(errorMsg, fieldName)));
        return errorResponse;
    }

    /**
     * Add specified error without lookup
     */
    public ErrorResponse addStaticError(String errorCode, String errorMsg) {
        errorResponse.addError(new Error(errorCode, errorMsg));
        return errorResponse;
    }

    public String getErrorMessage(String errorCode) {
        return messageSource.getMessage(errorCode, null, "", LocaleContextHolder.getLocale());
    }
}

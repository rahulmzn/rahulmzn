package com.neom.fss.neompay.communicationsmanagerconsumer.service.impl;

import com.google.firebase.messaging.AndroidConfig;
import com.google.firebase.messaging.AndroidNotification;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import com.neom.fss.neompay.communicationsmanager.MessageStatusOuterClass.MessageStatus;
import com.neom.fss.neompay.communicationsmanagerconsumer.constants.NotificationParameter;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.MessageResponse;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.PushNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.service.FirebaseService;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.stereotype.Service;

/**
 * please add required java docs for service
 */
@RequiredArgsConstructor
@Flogger
@Service
public class FirebaseServiceImpl implements FirebaseService {

    private final FirebaseMessaging firebaseMessaging;

    public List<MessageResponse> sendNotification(PushNotificationDetails notificationDetails, String kafkaKey)  {
        Notification notification = Notification
            .builder()
            .setTitle(notificationDetails.getTitle())
            .setBody(notificationDetails.getMessageBody())
            .build();

        return notificationDetails.getTo().stream().map(token -> {
            try {
                return MessageResponse.builder().messageId(sendMessage(notification, token,
                        notificationDetails.getDeepLinkUrl()))
                    .kafkaId(kafkaKey)
                    .messageStatus(MessageStatus.SENT).build();
            } catch (FirebaseMessagingException e) {
                log.atSevere().withCause(e).log(e.getMessage());
                return MessageResponse.builder().kafkaId(kafkaKey)
                    .messageStatus(MessageStatus.FAILED).build();
            }
        }).collect(Collectors.toList());

    }

    private String sendMessage(Notification notification, String token, String deepLinkUrl) throws FirebaseMessagingException {
        Message message = Message
            .builder()
            .setToken(token)
            .setNotification(notification)
            .putData("dl",deepLinkUrl)
            .setAndroidConfig(getAndroidConfig(token))
            .build();
        return firebaseMessaging.send(message);
    }


    private AndroidConfig getAndroidConfig(String topic) {
        return AndroidConfig.builder()
            .setTtl(Duration.ofMinutes(6).toMillis()).setCollapseKey(topic)
            .setPriority(AndroidConfig.Priority.HIGH)
            .setNotification(AndroidNotification.builder().setSound(NotificationParameter.SOUND.getValue())
                .setColor(NotificationParameter.COLOR.getValue()).setTag(topic).build()).build();
    }
}

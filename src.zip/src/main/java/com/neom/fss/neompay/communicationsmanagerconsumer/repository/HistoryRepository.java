package com.neom.fss.neompay.communicationsmanagerconsumer.repository;

import com.neom.fss.neompay.communicationsmanagerconsumer.repository.entity.HistoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;


public interface HistoryRepository extends JpaRepository<HistoryEntity, Integer> {

}

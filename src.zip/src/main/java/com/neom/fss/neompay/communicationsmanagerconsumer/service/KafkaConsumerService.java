package com.neom.fss.neompay.communicationsmanagerconsumer.service;

import com.google.protobuf.InvalidProtocolBufferException;

public interface KafkaConsumerService {

    void consume(byte[] message, String kafkaKey, int partition , String correlationId) throws InvalidProtocolBufferException;

}


package com.neom.fss.neompay.communicationsmanagerconsumer.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.communicationsmanager.MessageStatusOuterClass.MessageStatus;
import com.neom.fss.neompay.communicationsmanagerconsumer.config.UnifonicConfig;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.SmsNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.repository.AuditRepository;
import com.neom.fss.neompay.communicationsmanagerconsumer.service.SmsMessagingService;
import com.unifonic.api.RestApi;
import java.time.Duration;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Flogger
@Service
@ConditionalOnProperty(value = "services.unifonic.use-unifonic-service", havingValue = "true", matchIfMissing = true)
@RequiredArgsConstructor
public class UnifonicMessagingServiceImpl implements SmsMessagingService {

    public static final String RESPONSE_TYPE = "JSON";

    public static final String STATUS_CALLBACK = "sent";

    private final RestApi restApi;

    private final UnifonicConfig unifonicConfig;

    private  final AuditRepository auditRepository;

    private final ObjectMapper objectMapper;

    @Override
    @Transactional
    public void send(SmsNotificationDetails notificationDetails, String kafkaKey) {
        for (String recipient: notificationDetails.getTo()) {
            try {
                //To-do do not use block, use subscribe but need to consider how to use Transactional with WebClient
                restApi.sendmessage(unifonicConfig.getAppSid(),
                        unifonicConfig.getSenderId(),
                        notificationDetails.getMessageBody(), Long.parseLong(recipient), RESPONSE_TYPE,
                        notificationDetails.getCorrelationId(), true, STATUS_CALLBACK, false)
                    .blockOptional(Duration.ofMillis(Long.parseLong(unifonicConfig.getTimeoutMs())))
                    .ifPresent(sendResponse -> {
                        if (Boolean.FALSE.equals(Boolean.parseBoolean(sendResponse.getSuccess()))) {
                            log.atSevere().log(sendResponse.getMessage());
                            throw  new WebClientResponseException(sendResponse.getMessage(), HttpStatus.BAD_REQUEST.value(),
                                HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
                        } else {
                            log.atFine().log(sendResponse.toString());
                            Map<String, String> data = objectMapper.convertValue(sendResponse.getData(), Map.class);
                            auditRepository.updateAuditMessageStatusAndMessageId(MessageStatus.SENT,String.valueOf(data.get("MessageID")),kafkaKey );
                        }
                    } );
            } catch (WebClientResponseException ex){
                log.atSevere().withCause(ex).log(ex.getMessage());
                auditRepository.updateAuditMessageStatusAndMessageId(MessageStatus.FAILED,"",kafkaKey );
            }
        }
    }
}

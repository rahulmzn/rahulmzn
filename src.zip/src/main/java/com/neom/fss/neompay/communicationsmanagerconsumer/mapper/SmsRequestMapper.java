package com.neom.fss.neompay.communicationsmanagerconsumer.mapper;




import com.neom.fss.neompay.communicationsmanager.MobileNumberOuterClass.MobileNumber;
import com.neom.fss.neompay.communicationsmanager.SmsRequest.SMSRequest;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.SmsNotificationDetails;
import java.util.List;
import java.util.stream.Collectors;
import org.mapstruct.CollectionMappingStrategy;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.util.StringUtils;

/**
 * Use library mapper like mapstruct etc.
 * <p>
 * toMap and fromMap
 */

@Mapper(componentModel = "spring",
    collectionMappingStrategy = CollectionMappingStrategy.TARGET_IMMUTABLE,
    injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public interface SmsRequestMapper {

    @Mapping(target="to", expression = "java(mapListMobile(request.getSmsNotificationDetailsOrBuilder().getToList()))")
    @Mapping(target="messageBody", expression = "java(mapEmptyString(request.getSmsNotificationDetailsOrBuilder().getMessageBody()))")
    @Mapping(target = "correlationId", ignore = true)
    SmsNotificationDetails map(SMSRequest request);

    default String mapEmptyString(String string) {
        return StringUtils.hasText(string) ? string : "";
    }

    default List<String> mapListMobile(List<MobileNumber> to) {
        return to.stream().map(MobileNumber::getNumber).collect(Collectors.toList());
    }
}

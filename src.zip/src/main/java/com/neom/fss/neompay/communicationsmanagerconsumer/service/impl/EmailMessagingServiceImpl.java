package com.neom.fss.neompay.communicationsmanagerconsumer.service.impl;

import com.neom.fss.neompay.communicationsmanager.MessageStatusOuterClass.MessageStatus;
import com.neom.fss.neompay.communicationsmanagerconsumer.config.EmailConfig;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.EmailNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.MessageResponse;
import com.neom.fss.neompay.communicationsmanagerconsumer.service.EmailMessagingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Flogger
@Service
@RequiredArgsConstructor
public class EmailMessagingServiceImpl implements EmailMessagingService {

    private final JavaMailSender javaMailSender;

    private  final EmailConfig config;

    @Override
    public MessageResponse send(EmailNotificationDetails notificationDetails, String kafkaKey) {

        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(notificationDetails.getTo().toArray(new String[0]));
        msg.setCc(notificationDetails.getCc().toArray(new String[0]));
        msg.setFrom(config.getSenderId());

        msg.setSubject(notificationDetails.getSubject());
        msg.setText(notificationDetails.getMessageBody());

        try {
            javaMailSender.send(msg);
            log.atInfo().log(String.format("Email Message with key %s has been Sent", kafkaKey));
            return MessageResponse.builder().messageId(kafkaKey).messageStatus(MessageStatus.SENT).build();
        }
        catch (MailException ex){
            log.atSevere().withCause(ex).log(ex.getMessage());
            return MessageResponse.builder().messageId(kafkaKey).messageStatus(MessageStatus.FAILED).build();
        }
    }
}

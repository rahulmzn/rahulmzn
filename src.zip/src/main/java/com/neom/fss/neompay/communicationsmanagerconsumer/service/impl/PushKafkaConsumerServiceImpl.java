package com.neom.fss.neompay.communicationsmanagerconsumer.service.impl;

import com.google.protobuf.InvalidProtocolBufferException;
import com.neom.fss.neompay.communicationsmanager.MessageStatusOuterClass.MessageStatus;
import com.neom.fss.neompay.communicationsmanager.PushRequestOuterClass.PushRequest;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.MessageResponse;
import com.neom.fss.neompay.communicationsmanagerconsumer.mapper.PushRequestMapper;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.PushNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.repository.AuditRepository;
import com.neom.fss.neompay.communicationsmanagerconsumer.repository.entity.AuditEntity;
import com.neom.fss.neompay.communicationsmanagerconsumer.service.FirebaseService;
import com.neom.fss.neompay.communicationsmanagerconsumer.service.KafkaConsumerService;
import java.util.Arrays;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Flogger
@Service
@RequiredArgsConstructor
public class PushKafkaConsumerServiceImpl implements KafkaConsumerService{

    private final FirebaseService firebaseService;

    private final PushRequestMapper requestMapper;

    private  final AuditRepository auditRepository;

    @KafkaListener(topics = "push", groupId = "${spring.kafka.consumer.group-id}",
        containerFactory = "kafkaPushListenerContainerFactory")
    @Override
    @Transactional
    public void consume(@Payload byte[] message,
        @Header(KafkaHeaders.RECEIVED_MESSAGE_KEY) String kafkaKey,
        @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition,
        @Header(KafkaHeaders.CORRELATION_ID) String correlationId) throws InvalidProtocolBufferException {
        log.atFine().log(
            "Received Message: " + Arrays.toString(message)
                + " from partition: " + partition + ", from kafkaKey: " + kafkaKey);

        PushRequest request = PushRequest.parseFrom(message);
        for ( String to: request.getPushNotificationDetails().getToList()) {
            auditRepository.save(AuditEntity.builder()
                .intMessageId(kafkaKey)
                .status(MessageStatus.INITIATED)
                .idType("CORRELATION_ID")
                .idValue(correlationId)
                .recipient(to)
                .build());
        }

        log.atFine().log(
            "Parsed Received Message: " + request);

        PushNotificationDetails notificationDetails = requestMapper.map(
            request);

        List<MessageResponse> messageResponses = firebaseService.sendNotification(
            notificationDetails, kafkaKey);

        for (MessageResponse response: messageResponses ) {
            auditRepository.updateAuditMessageStatusAndMessageId(response.getMessageStatus(),response.getMessageId(),response.getKafkaId());
        }

    }
}

package com.neom.fss.neompay.communicationsmanagerconsumer.mapper;

import com.neom.fss.neompay.communicationsmanager.PushRequestOuterClass.PushRequest;
import org.springframework.stereotype.Component;

@Component
public class ObjectFactory {

    public PushRequest.Builder pushRequestBuilder() {
        return PushRequest.newBuilder();
    }

}

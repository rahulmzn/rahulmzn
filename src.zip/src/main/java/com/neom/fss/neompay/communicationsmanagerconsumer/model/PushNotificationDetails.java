package com.neom.fss.neompay.communicationsmanagerconsumer.model;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class PushNotificationDetails {

    private List<String> to;

    private String deviceType;

    private String title;

    private String messageBody;

    private String deepLinkUrl;

}

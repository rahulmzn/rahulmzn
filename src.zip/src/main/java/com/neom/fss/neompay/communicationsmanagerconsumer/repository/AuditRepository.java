package com.neom.fss.neompay.communicationsmanagerconsumer.repository;

import com.neom.fss.neompay.communicationsmanager.MessageStatusOuterClass.MessageStatus;
import com.neom.fss.neompay.communicationsmanagerconsumer.repository.entity.AuditEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface AuditRepository extends JpaRepository<AuditEntity, Integer> {

    @Modifying
    @Query("update AuditEntity a set a.status = :status, a.extMessageId = :extMessageId where a.intMessageId = :intMessageId")
    void updateAuditMessageStatusAndMessageId(@Param("status") MessageStatus status,@Param("extMessageId") String extMessageId,
        @Param("intMessageId") String intMessageId);
}

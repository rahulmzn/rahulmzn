package com.neom.fss.neompay.communicationsmanagerconsumer.service;


import com.neom.fss.neompay.communicationsmanagerconsumer.model.EmailNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.MessageResponse;

public interface EmailMessagingService {

    MessageResponse send(EmailNotificationDetails notificationDetails, String kafkaKey);

}

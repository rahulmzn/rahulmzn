package com.neom.fss.neompay.communicationsmanagerconsumer.config;

import com.unifonic.api.RestApi;
import com.unifonic.invoker.ApiClient;
import com.unifonic.invoker.auth.HttpBasicAuth;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Getter
@Configuration
public class UnifonicConfig {

    @Value("${services.unifonic.service-address}")
    private String serviceAddress;

    @Value("${services.unifonic.user-name}")
    private String userName;

    @Value("${services.unifonic.password}")
    private String password;

    @Value("${services.unifonic.app-sid}")
    private String appSid;

    @Value("${services.unifonic.timeout-ms}")
    private String timeoutMs;

    @Value("${services.unifonic.senderID}")
    private String senderId;

    @Bean
    public RestApi unifonicApi() {
        return new RestApi(apiClient());
    }

    @Bean
    public ApiClient apiClient() {
        ApiClient apiClient = new ApiClient();
        apiClient.setBasePath(serviceAddress);

        HttpBasicAuth httpBasic = (HttpBasicAuth) apiClient.getAuthentication("httpBasic");
        httpBasic.setUsername(userName);
        httpBasic.setPassword(password);

        return apiClient;
    }
}

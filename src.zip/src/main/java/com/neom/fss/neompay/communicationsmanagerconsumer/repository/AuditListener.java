package com.neom.fss.neompay.communicationsmanagerconsumer.repository;

import com.neom.fss.neompay.communicationsmanagerconsumer.repository.entity.HistoryEntity;
import com.neom.fss.neompay.communicationsmanagerconsumer.repository.entity.AuditEntity;
import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class AuditListener {

    private final HistoryRepository historyRepository;

    public AuditListener(
        @Lazy HistoryRepository historyRepository) {
        this.historyRepository = historyRepository;
    }

    @PostPersist
    @PostUpdate
    @Transactional
    public void afterPersist(final AuditEntity auditEntity) {
       HistoryEntity historyEntity =  HistoryEntity.create(auditEntity);
       historyRepository.save(historyEntity);
    }

}

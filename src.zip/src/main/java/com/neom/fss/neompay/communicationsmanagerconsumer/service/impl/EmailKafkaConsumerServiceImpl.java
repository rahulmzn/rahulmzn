package com.neom.fss.neompay.communicationsmanagerconsumer.service.impl;

import com.google.protobuf.InvalidProtocolBufferException;
import com.neom.fss.neompay.communicationsmanager.EmailAddressOuterClass.EmailAddress;
import com.neom.fss.neompay.communicationsmanager.EmailRequestOuterClass.EmailRequest;
import com.neom.fss.neompay.communicationsmanager.MessageStatusOuterClass.MessageStatus;
import com.neom.fss.neompay.communicationsmanager.MobileNumberOuterClass.MobileNumber;
import com.neom.fss.neompay.communicationsmanager.SmsRequest.SMSRequest;
import com.neom.fss.neompay.communicationsmanagerconsumer.mapper.EmailRequestMapper;
import com.neom.fss.neompay.communicationsmanagerconsumer.mapper.SmsRequestMapper;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.EmailNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.MessageResponse;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.SmsNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.repository.AuditRepository;
import com.neom.fss.neompay.communicationsmanagerconsumer.repository.entity.AuditEntity;
import com.neom.fss.neompay.communicationsmanagerconsumer.service.EmailMessagingService;
import com.neom.fss.neompay.communicationsmanagerconsumer.service.KafkaConsumerService;
import com.neom.fss.neompay.communicationsmanagerconsumer.service.SmsMessagingService;
import java.util.Arrays;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Flogger
@Service
@RequiredArgsConstructor
public class EmailKafkaConsumerServiceImpl implements KafkaConsumerService{

    private final EmailRequestMapper requestMapper;

    private  final AuditRepository auditRepository;

    private final EmailMessagingService emailMessagingService;

    @KafkaListener(topics = "email", groupId = "${spring.kafka.consumer.group-id}",
        containerFactory = "kafkaEmailListenerContainerFactory")
    @Override
    @Transactional
    public void consume(@Payload byte[] message,
        @Header(KafkaHeaders.RECEIVED_MESSAGE_KEY) String kafkaKey,
        @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition,
        @Header(KafkaHeaders.CORRELATION_ID) String correlationId) throws InvalidProtocolBufferException {

        log.atFine().log(
            "Received Message: " + Arrays.toString(message)
                + " from partition: " + partition + ", from kafkaKey: " + kafkaKey);

        EmailRequest request = EmailRequest.parseFrom(message);

        for ( EmailAddress to: request.getEmailNotificationDetails().getToList()) {
            auditRepository.save(AuditEntity.builder()
                .intMessageId(kafkaKey)
                .status(MessageStatus.INITIATED)
                .idType("CORRELATION_ID")
                .idValue(correlationId)
                .recipient(to.getAddress())
                .build());
        }

        log.atFine().log(
            "Parsed Received Message: " + request);

        EmailNotificationDetails notificationDetails = requestMapper.map(
            request);

        notificationDetails.setCorrelationId(correlationId);

        MessageResponse response = emailMessagingService.send(
            notificationDetails, kafkaKey);

        auditRepository.updateAuditMessageStatusAndMessageId(response.getMessageStatus(),
            response.getMessageId(),response.getKafkaId());
    }
}

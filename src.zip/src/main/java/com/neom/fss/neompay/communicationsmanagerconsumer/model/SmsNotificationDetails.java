package com.neom.fss.neompay.communicationsmanagerconsumer.model;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
public class SmsNotificationDetails {
    private List<String> to;

    private String messageBody;

    private String correlationId;
}

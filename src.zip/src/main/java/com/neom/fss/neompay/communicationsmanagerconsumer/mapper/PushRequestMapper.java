package com.neom.fss.neompay.communicationsmanagerconsumer.mapper;


import com.neom.fss.neompay.communicationsmanager.PushRequestOuterClass;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.PushNotificationDetails;
import org.mapstruct.CollectionMappingStrategy;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.util.StringUtils;

/**
 * Use library mapper like mapstruct etc.
 * <p>
 * toMap and fromMap
 */

@Mapper(componentModel = "spring",
    collectionMappingStrategy = CollectionMappingStrategy.TARGET_IMMUTABLE,
    injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public interface PushRequestMapper {

    @Mapping(target="to", expression = "java(request.getPushNotificationDetailsOrBuilder().getToList())")
    @Mapping(target="deviceType", expression = "java(request.getPushNotificationDetailsOrBuilder().getDeviceType())")
    @Mapping(target="messageBody", expression = "java(request.getPushNotificationDetailsOrBuilder().getMessageBody())")
    @Mapping(target="title", expression = "java(request.getPushNotificationDetailsOrBuilder().getTitle())")
    @Mapping(target="deepLinkUrl", expression = "java(request.getPushNotificationDetailsOrBuilder().getDeepLinkUrl())")
    PushNotificationDetails map(PushRequestOuterClass.PushRequest request);

    default String mapEmptyString(String string) {
        return StringUtils.hasText(string) ? string : "";
    }
}

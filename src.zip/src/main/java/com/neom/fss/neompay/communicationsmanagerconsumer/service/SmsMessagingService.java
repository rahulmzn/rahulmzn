package com.neom.fss.neompay.communicationsmanagerconsumer.service;


import com.neom.fss.neompay.communicationsmanagerconsumer.model.SmsNotificationDetails;

public interface SmsMessagingService {

    void send(SmsNotificationDetails notificationDetails, String kafkaKey);

}

package com.neom.fss.neompay.communicationsmanagerconsumer.mapper;


import com.neom.fss.neompay.communicationsmanager.EmailAddressOuterClass.EmailAddress;
import com.neom.fss.neompay.communicationsmanager.EmailRequestOuterClass.EmailRequest;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.EmailNotificationDetails;
import java.util.List;
import java.util.stream.Collectors;
import org.mapstruct.CollectionMappingStrategy;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.util.StringUtils;

/**
 * Use library mapper like mapstruct etc.
 * <p>
 * toMap and fromMap
 */

@Mapper(componentModel = "spring",
    collectionMappingStrategy = CollectionMappingStrategy.TARGET_IMMUTABLE,
    injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public interface EmailRequestMapper {

    @Mapping(target="to", expression = "java(mapListEmail(request.getEmailNotificationDetailsOrBuilder().getToList()))")
    @Mapping(target="cc", expression = "java(mapListEmail(request.getEmailNotificationDetailsOrBuilder().getCcList()))")
    @Mapping(target="messageBody", expression = "java(mapEmptyString(request.getEmailNotificationDetailsOrBuilder().getMessageBody()))")
    @Mapping(target="subject", expression = "java(mapEmptyString(request.getEmailNotificationDetailsOrBuilder().getSubject()))")
    @Mapping(target = "correlationId", ignore = true)
    EmailNotificationDetails map(EmailRequest request);

    default String mapEmptyString(String string) {
        return StringUtils.hasText(string) ? string : "";
    }

    default List<String> mapListEmail(List<EmailAddress> to) {
        return to.stream().map(EmailAddress::getAddress).collect(Collectors.toList());
    }
}

package com.neom.fss.neompay.communicationsmanagerconsumer.service;

import com.neom.fss.neompay.communicationsmanagerconsumer.model.MessageResponse;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.PushNotificationDetails;
import java.util.List;

public interface FirebaseService {

    List<MessageResponse> sendNotification(PushNotificationDetails notificationDetails, String kafkaKey);
}

package com.neom.fss.neompay.communicationsmanagerconsumer.service.impl;

import com.neom.fss.neompay.communicationsmanagerconsumer.model.SmsNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.service.SmsMessagingService;
import lombok.extern.flogger.Flogger;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

@Flogger
@Service
@ConditionalOnProperty(value = "services.unifonic.use-unifonic-service", havingValue = "false")
public class MockSmsMessagingService implements SmsMessagingService {

    @Override
    public void send(SmsNotificationDetails notificationDetails, String kafkaKey) {
        log.atInfo().log("SMS Messaging is Turned Off. Message Body : %s for mobile number %s",
            notificationDetails.getMessageBody(), notificationDetails.getTo().get(0));
    }
}

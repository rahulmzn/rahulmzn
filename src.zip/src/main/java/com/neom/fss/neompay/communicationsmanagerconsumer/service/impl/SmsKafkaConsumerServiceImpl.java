package com.neom.fss.neompay.communicationsmanagerconsumer.service.impl;

import com.google.protobuf.InvalidProtocolBufferException;
import com.neom.fss.neompay.communicationsmanager.MessageStatusOuterClass.MessageStatus;
import com.neom.fss.neompay.communicationsmanager.MobileNumberOuterClass.MobileNumber;
import com.neom.fss.neompay.communicationsmanager.SmsRequest.SMSRequest;
import com.neom.fss.neompay.communicationsmanagerconsumer.config.UnifonicConfig;
import com.neom.fss.neompay.communicationsmanagerconsumer.mapper.SmsRequestMapper;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.SmsNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.repository.AuditRepository;
import com.neom.fss.neompay.communicationsmanagerconsumer.repository.entity.AuditEntity;
import com.neom.fss.neompay.communicationsmanagerconsumer.service.KafkaConsumerService;
import com.neom.fss.neompay.communicationsmanagerconsumer.service.SmsMessagingService;
import com.unifonic.api.RestApi;
import java.util.Arrays;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;

@Flogger
@Service
@RequiredArgsConstructor
public class SmsKafkaConsumerServiceImpl implements KafkaConsumerService{

    private final SmsRequestMapper requestMapper;

    private  final AuditRepository auditRepository;

    private final SmsMessagingService smsMessagingService;

    @KafkaListener(topics = "sms", groupId = "${spring.kafka.consumer.group-id}",
        containerFactory = "kafkaSmsListenerContainerFactory")
    @Override
    @Transactional
    public void consume(@Payload byte[] message,
        @Header(KafkaHeaders.RECEIVED_MESSAGE_KEY) String kafkaKey,
        @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition,
        @Header(KafkaHeaders.CORRELATION_ID) String correlationId) throws InvalidProtocolBufferException {

        log.atFine().log(
            "Received Message: " + Arrays.toString(message)
                + " from partition: " + partition + ", from kafkaKey: " + kafkaKey);

        SMSRequest request = SMSRequest.parseFrom(message);

        for ( MobileNumber to: request.getSmsNotificationDetails().getToList()) {
            auditRepository.save(AuditEntity.builder()
                .intMessageId(kafkaKey)
                .status(MessageStatus.INITIATED)
                .idType("CORRELATION_ID")
                .idValue(correlationId)
                .recipient(to.getNumber())
                .build());
        }

        log.atFine().log(
            "Parsed Received Message: " + request);

        SmsNotificationDetails notificationDetails = requestMapper.map(
            request);
        notificationDetails.setCorrelationId(correlationId);

        smsMessagingService.send(notificationDetails, kafkaKey);
    }
}

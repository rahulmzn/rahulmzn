package com.neom.fss.neompay.communicationsmanagerconsumer.repository.entity;

import com.neom.fss.neompay.communicationsmanager.MessageStatusOuterClass.MessageStatus;
import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Table(name = "comms_history")
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class HistoryEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private Integer auditId;

    private String intMessageId;

    @Enumerated(EnumType.STRING)
    private MessageStatus status;

    private LocalDateTime createdAt;

    public static HistoryEntity create(AuditEntity auditEntity){
        return HistoryEntity.builder()
            .auditId(auditEntity.getId())
            .createdAt(LocalDateTime.now())
            .intMessageId(auditEntity.getIntMessageId())
            .status(auditEntity.getStatus()).build();
    }

}

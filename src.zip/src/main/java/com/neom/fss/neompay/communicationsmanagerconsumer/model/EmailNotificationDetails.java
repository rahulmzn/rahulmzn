package com.neom.fss.neompay.communicationsmanagerconsumer.model;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
public class EmailNotificationDetails {

    private List<String> to;

    private List<String> cc;

    private String subject;

    private String messageBody;

    private String correlationId;
}

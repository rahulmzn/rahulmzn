package com.neom.fss.neompay.communicationsmanagerconsumer.service.impl;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.google.protobuf.InvalidProtocolBufferException;
import com.neom.fss.neompay.communicationsmanager.MessageStatusOuterClass.MessageStatus;
import com.neom.fss.neompay.communicationsmanagerconsumer.mapper.EmailRequestMapper;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.EmailNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.MessageResponse;
import com.neom.fss.neompay.communicationsmanagerconsumer.repository.AuditRepository;
import com.neom.fss.neompay.communicationsmanagerconsumer.service.EmailMessagingService;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class EmailKafkaConsumerServiceImplTest {

    @Mock
    private EmailRequestMapper requestMapper;

    @Mock
    private  AuditRepository auditRepository;

    @Mock
    private EmailMessagingService emailMessagingService;

    @InjectMocks
    private EmailKafkaConsumerServiceImpl kafkaConsumerService;

    @BeforeEach
    void setUp() {
    }

    @Test
    void consume() throws InvalidProtocolBufferException {
        EmailNotificationDetails notificationDetails = EmailNotificationDetails.builder().messageBody("hello").correlationId("Corr-id")
            .to(
                List.of("johndoe@gamil.com")).build();
        //Given
        when(requestMapper.map(any())).thenReturn(notificationDetails);
        MessageResponse messageResponse = MessageResponse.builder().messageStatus(MessageStatus.SENT).messageId("id")
            .kafkaId("kafka").build();
        when(emailMessagingService.send(eq(notificationDetails),any())).thenReturn(messageResponse);
        //When
        kafkaConsumerService.consume(getSampleMessage(),"kafka-key",0,"corr-id");

        //Then
        Mockito.verify(emailMessagingService,Mockito.atLeastOnce()).send(any(),any());
        Mockito.verify(auditRepository,Mockito.atLeastOnce()).save(any());
        Mockito.verify(auditRepository,Mockito.atLeastOnce()).updateAuditMessageStatusAndMessageId(any(),any(), any());
    }

    private byte[] getSampleMessage() {
        return new byte[]{
            10, 37, 18, 7, 109, 101, 115, 115, 97, 103, 101, 26, 19, 10, 17, 106, 111, 104, 110, 100, 111, 101, 64, 103, 109, 97, 105, 108, 46, 99, 111, 109, 42, 5, 104, 101, 108, 108, 111
        };
    }

}
package com.neom.fss.neompay.communicationsmanagerconsumer.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.neom.fss.neompay.communicationsmanager.MessageStatusOuterClass.MessageStatus;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.MessageResponse;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.PushNotificationDetails;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class FirebaseServiceImplTest {

    @Mock
    private FirebaseMessaging firebaseMessaging;

    @InjectMocks
    private FirebaseServiceImpl firebaseService;

    @Test
    void sendNotification() throws FirebaseMessagingException {
        when(firebaseMessaging.send(any())).thenReturn("firebase_id");

        PushNotificationDetails notification = PushNotificationDetails.builder()
            .title("Title")
            .to(List.of("12555"))
            .deepLinkUrl("url")
            .messageBody("Hello").build();
        List<MessageResponse> response = firebaseService.sendNotification(
            notification, "kafka_key");

        assertEquals(1, response.size());
        MessageResponse messageResponse = response.get(0);
        assertNotNull(messageResponse);
        assertEquals(MessageStatus.SENT,messageResponse.getMessageStatus());
    }

    @Test
    void sendNotificationExceptionThrown() throws FirebaseMessagingException {
        when(firebaseMessaging.send(any())).thenThrow(new RuntimeException());

        PushNotificationDetails notification = PushNotificationDetails.builder()
            .title("Title")
            .to(List.of("12555"))
            .deepLinkUrl("url")
            .messageBody("Hello").build();

        Assertions.assertThrows(RuntimeException.class, () -> {
            firebaseService.sendNotification(
                notification, "kafka_key");
        });
    }
}
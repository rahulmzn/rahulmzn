package com.neom.fss.neompay.communicationsmanagerconsumer.service.impl;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;
import static reactor.core.publisher.Mono.when;

import com.google.protobuf.InvalidProtocolBufferException;
import com.neom.fss.neompay.communicationsmanager.MessageStatusOuterClass.MessageStatus;
import com.neom.fss.neompay.communicationsmanagerconsumer.mapper.PushRequestMapper;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.MessageResponse;
import com.neom.fss.neompay.communicationsmanagerconsumer.repository.AuditRepository;
import com.neom.fss.neompay.communicationsmanagerconsumer.service.FirebaseService;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class PushKafkaConsumerServiceImplTest {

    @Mock
    private  FirebaseService firebaseService;

    @Mock
    private  PushRequestMapper requestMapper;

    @Mock
    private  AuditRepository auditRepository;

    @InjectMocks
    private PushKafkaConsumerServiceImpl kafkaConsumerService;

    @Test
    void consume() throws InvalidProtocolBufferException {
        //Given
        when(firebaseService.sendNotification(any(),any())).thenReturn(getMessageResponses());

        //When
        kafkaConsumerService.consume(getSampleMessage(),"kafka-key",0,"corr-id");

        //Then
        Mockito.verify(firebaseService,Mockito.atLeastOnce()).sendNotification(any(),any());
        Mockito.verify(auditRepository,times(1)).save(any());
        Mockito.verify(auditRepository,times(1)).updateAuditMessageStatusAndMessageId(any(),any(),any());
    }

    private List<MessageResponse> getMessageResponses() {
        return List.of(MessageResponse.builder().messageId("1234").kafkaId("kafka-id").messageStatus(
            MessageStatus.SENT).build());
    }

    private byte[] getSampleMessage() {

        return new byte[]{
            10,-67  ,1  ,18  ,5  ,72  ,101  ,108  ,108  ,111  , 26  , -93  , 1  , 100  , 78  , 72  , 51  , 80  , 95  , 53  , 67  , 81  , 68  , 113  , 70  , 54  , 90  , 83  , 110  , 110  , 115  , 66  , 54  , 116  , 119  , 58  , 65  , 80  , 65  , 57  , 49  , 98  , 72  , 57  , 45  , 103  , 115  , 108  , 85  , 79  , 87  , 118  , 77  , 57  , 111  , 116  , 65  , 75  , 57  , 103  , 81  , 101  , 72  , 53  , 99  , 119  , 98  , 74  , 54  , 112  , 97  , 83  , 75  , 99  , 117  , 103  , 84  , 102  , 107  , 122  , 72  , 83  , 89  , 101  , 111  , 68  , 122  , 118  , 82  , 112  , 76  , 111  , 110  , 85  , 106  , 114  , 81  , 87  , 117  , 78  , 76  , 67  , 115  , 115  , 50  , 52  , 104  , 48  , 95  , 73  , 114  , 74  , 116  , 70  , 108  , 45  , 79  , 113  , 107  , 74  , 102  , 55  , 56  , 98  , 49  , 90  , 85  , 53  , 57  , 67  , 65  , 88  , 99  , 114  , 108  , 112  , 122  , 75  , 69  , 48  , 52  , 73  , 119  , 77  , 89  , 77  , 71  , 68  , 104  , 104  , 104  , 115  , 57  , 115  , 103  , 112  , 112  , 69  , 86  , 116  , 97  , 80  , 84  , 73  , 88  , 119  , 116  , 80  , 75  , 67  , 97  , 82  , 53  , 105  , 57  , 81  , 34  , 7  , 65  , 110  , 100  , 114  , 111  , 105  , 100  , 42  , 5  , 116  , 105  , 116  , 108  , 101
        };
    }
}
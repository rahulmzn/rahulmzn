package com.neom.fss.neompay.communicationsmanagerconsumer.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.google.protobuf.InvalidProtocolBufferException;
import com.neom.fss.neompay.communicationsmanagerconsumer.mapper.PushRequestMapper;
import com.neom.fss.neompay.communicationsmanagerconsumer.mapper.SmsRequestMapper;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.SmsNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.repository.AuditRepository;
import com.neom.fss.neompay.communicationsmanagerconsumer.service.FirebaseService;
import com.neom.fss.neompay.communicationsmanagerconsumer.service.SmsMessagingService;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SmsKafkaConsumerServiceImplTest {

    @Mock
    private SmsRequestMapper requestMapper;

    @Mock
    private AuditRepository auditRepository;

    @Mock
    private SmsMessagingService smsMessagingService;

    @InjectMocks
    private SmsKafkaConsumerServiceImpl kafkaConsumerService;


    @Test
    void consume() throws InvalidProtocolBufferException {
        SmsNotificationDetails notificationDetails = SmsNotificationDetails.builder().messageBody("hello").correlationId("Corr-id")
            .to(
                List.of("445677809898")).build();
        //Given
        when(requestMapper.map(any())).thenReturn(notificationDetails);

        //When
        kafkaConsumerService.consume(getSampleMessage(),"kafka-key",0,"corr-id");

        //Then
        Mockito.verify(smsMessagingService,Mockito.atLeastOnce()).send(any(),any());
        Mockito.verify(auditRepository,Mockito.atLeastOnce()).save(any());
    }

    private byte[] getSampleMessage() {
        return new byte[]{
            10, 32, 18, 13, 72, 101, 108, 108, 111, 111, 111, 111, 111, 111, 111, 111, 111, 26, 15, 10, 13, 43, 52, 52, 55, 53, 51, 53, 54, 53, 48, 48, 48, 57
        };
    }
}
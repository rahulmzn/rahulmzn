package com.neom.fss.neompay.communicationsmanagerconsumer.service.impl;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.communicationsmanager.MessageStatusOuterClass.MessageStatus;
import com.neom.fss.neompay.communicationsmanagerconsumer.config.UnifonicConfig;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.SmsNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.repository.AuditRepository;
import com.unifonic.api.RestApi;
import com.unifonic.model.Sendresponse;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
class UnifonicMessagingServiceImplTest {

    @Mock
    private RestApi restApi;

    @Mock
    private UnifonicConfig unifonicConfig;

    @Mock
    private  AuditRepository auditRepository;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private UnifonicMessagingServiceImpl unifonicMessagingService;

    @BeforeEach
    void setUp() {
    }

    @Test
    void sendMessageSuccess() throws IOException, URISyntaxException {
        //Given
        when(unifonicConfig.getTimeoutMs()).thenReturn("10000");
        when(unifonicConfig.getAppSid()).thenReturn("100005thfhdfhd");

        SmsNotificationDetails notificationDetails = SmsNotificationDetails.builder().messageBody("hello").correlationId("Corr-id")
            .to(
                List.of("445677809898")).build();

        Sendresponse sendresponse = getSendresponse();
        when(restApi.sendmessage(any(),any(),any(),any(),eq("JSON"), eq(notificationDetails.getCorrelationId()),
            eq(true),eq("sent"),eq(false))).thenReturn(Mono.just(
            sendresponse));

        Map data = new ObjectMapper().convertValue(sendresponse.getData(), Map.class);

        when(objectMapper.convertValue(sendresponse.getData(),Map.class)).thenReturn(data);

        //When
        unifonicMessagingService.send(notificationDetails, "kafka-key");

        //Then
        verify(auditRepository,atLeastOnce()).updateAuditMessageStatusAndMessageId(any(),any(), any());
    }

    @Test
    void sendMessageError() throws IOException, URISyntaxException {
        //Given
        when(unifonicConfig.getTimeoutMs()).thenReturn("10000");
        when(unifonicConfig.getAppSid()).thenReturn("100005thfhdfhd");

        SmsNotificationDetails notificationDetails = SmsNotificationDetails.builder().messageBody("hello").correlationId("Corr-id")
            .to(
                List.of("445677809898")).build();

        Sendresponse sendresponse = getSendresponse();
        sendresponse.setSuccess("false");
        when(restApi.sendmessage(any(),any(),any(),any(),any(), any(),
            any(),any(),any())).thenReturn(Mono.just(sendresponse));

        //When
        unifonicMessagingService.send(notificationDetails, "kafka-key");

        //Then
        verify(auditRepository,atLeastOnce()).updateAuditMessageStatusAndMessageId(eq(MessageStatus.FAILED),any(), any());
    }

    private Sendresponse getSendresponse() throws IOException, URISyntaxException {
        return new ObjectMapper().readValue(Paths.get(ClassLoader.
            getSystemResource("sendResponse.json").toURI()).toFile(), Sendresponse.class);

    }

}
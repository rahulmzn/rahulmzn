package com.neom.fss.neompay.communicationsmanagerconsumer.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import com.neom.fss.neompay.communicationsmanager.MessageStatusOuterClass.MessageStatus;
import com.neom.fss.neompay.communicationsmanagerconsumer.config.EmailConfig;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.EmailNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.MessageResponse;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mail.MailSendException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

@ExtendWith(MockitoExtension.class)
class EmailMessagingServiceImplTest {

    @Mock
    private JavaMailSender javaMailSender;

    @Mock
    private EmailConfig config;

    @InjectMocks
    private EmailMessagingServiceImpl emailMessagingService;

    @BeforeEach
    void setUp() {
    }

    @Test
    void sendSuccessfulEmail() {
        //Given
        when(config.getSenderId()).thenReturn("app@neom");

        EmailNotificationDetails notificationDetails = EmailNotificationDetails.builder()
            .messageBody("hello")
            .subject("sub")
            .correlationId("Corr-id")
            .to(List.of("john@doe"))
            .cc(List.of("john@doe"))
            .build();

        //when
        MessageResponse response = emailMessagingService.send(
            notificationDetails, "kafka-key");

        //Then
        Mockito.verify(javaMailSender, Mockito.atLeastOnce()).send(any(SimpleMailMessage.class));
        assertNotNull(response);
        assertEquals(MessageStatus.SENT, response.getMessageStatus());
    }

    @Test
    void sendEmailError() {
        //Given
        when(config.getSenderId()).thenReturn("app@neom");

        EmailNotificationDetails notificationDetails = EmailNotificationDetails.builder()
            .messageBody("hello")
            .subject("sub")
            .correlationId("Corr-id")
            .to(List.of("john@doe"))
            .cc(List.of("john@doe"))
            .build();

        doThrow(new MailSendException("")).when(javaMailSender).send(any(SimpleMailMessage.class));

        //when
        MessageResponse response = emailMessagingService.send(
            notificationDetails, "kafka-key");

        //Then
        Mockito.verify(javaMailSender, Mockito.atLeastOnce()).send(any(SimpleMailMessage.class));
        assertNotNull(response);
        assertEquals(MessageStatus.FAILED, response.getMessageStatus());
    }
}
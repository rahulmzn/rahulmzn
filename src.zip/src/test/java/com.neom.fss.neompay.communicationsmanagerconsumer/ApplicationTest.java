//package com.neom.fss.neompay.communicationsmanagerconsumer;
//
//import static org.assertj.core.api.Assertions.assertThat;
//
//import com.neom.fss.neompay.communicationsmanagerconsumer.controller.HelloWorldAsJsonController;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class ApplicationTest {
//
//    @Autowired
//    private HelloWorldAsJsonController helloWorldAsJsonController;
//
//    @Test
//    void contextLoads() {
//        Application.main(new String[] {});
//        assertThat(helloWorldAsJsonController).isNotNull();
//    }
//
//}

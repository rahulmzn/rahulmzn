package com.unifonic.api;

import com.unifonic.invoker.ApiClient;

import com.unifonic.model.GetMessageQueryresponse;
import com.unifonic.model.SendWrapperresponse;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Flux;

@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen", date = "2022-10-26T17:30:54.972311+01:00[Europe/London]")
public class WrapperApi {
    private ApiClient apiClient;

    public WrapperApi() {
        this(new ApiClient());
    }

    @Autowired
    public WrapperApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Get msgQuery
     * Unifonic Get message query API allows you to get details of specified message.
     * <p><b>200</b>
     * <p><b>401</b> - Authentication failed
     * <p><b>402</b> - Missing parameter AppSid
     * <p><b>432</b> - MessageId must be numeric
     * <p><b>452</b> - User must specify either messageId or recipient parameter
     * @param appsid A character string that uniquely identifies your app
     * @param msgid A unique ID that identifies a message
     * @param to Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498)
     * @return GetMessageQueryresponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    private ResponseSpec getmsgQueryRequestCreation(String appsid, Long msgid, Long to) throws WebClientResponseException {
        Object postBody = null;
        // verify the required parameter 'appsid' is set
        if (appsid == null) {
            throw new WebClientResponseException("Missing the required parameter 'appsid' when calling getmsgQuery", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // verify the required parameter 'msgid' is set
        if (msgid == null) {
            throw new WebClientResponseException("Missing the required parameter 'msgid' when calling getmsgQuery", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // create path and map variables
        final Map<String, Object> pathParams = new HashMap<String, Object>();

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "appsid", appsid));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "msgid", msgid));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "to", to));

        final String[] localVarAccepts = { 
            "application/json"
        };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[] { "httpBasic" };

        ParameterizedTypeReference<GetMessageQueryresponse> localVarReturnType = new ParameterizedTypeReference<GetMessageQueryresponse>() {};
        return apiClient.invokeAPI("/wrapper/msgQuery", HttpMethod.POST, pathParams, queryParams, postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    }

    /**
     * Get msgQuery
     * Unifonic Get message query API allows you to get details of specified message.
     * <p><b>200</b>
     * <p><b>401</b> - Authentication failed
     * <p><b>402</b> - Missing parameter AppSid
     * <p><b>432</b> - MessageId must be numeric
     * <p><b>452</b> - User must specify either messageId or recipient parameter
     * @param appsid A character string that uniquely identifies your app
     * @param msgid A unique ID that identifies a message
     * @param to Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498)
     * @return GetMessageQueryresponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<GetMessageQueryresponse> getmsgQuery(String appsid, Long msgid, Long to) throws WebClientResponseException {
        ParameterizedTypeReference<GetMessageQueryresponse> localVarReturnType = new ParameterizedTypeReference<GetMessageQueryresponse>() {};
        return getmsgQueryRequestCreation(appsid, msgid, to).bodyToMono(localVarReturnType);
    }

    public Mono<ResponseEntity<GetMessageQueryresponse>> getmsgQueryWithHttpInfo(String appsid, Long msgid, Long to) throws WebClientResponseException {
        ParameterizedTypeReference<GetMessageQueryresponse> localVarReturnType = new ParameterizedTypeReference<GetMessageQueryresponse>() {};
        return getmsgQueryRequestCreation(appsid, msgid, to).toEntity(localVarReturnType);
    }
    /**
     * Send message
     * Unifonic Send Wrapper API allows you to send  text messages to  multiple users at the same time
     * <p><b>200</b>
     * <p><b>401</b> - Authentication failed
     * <p><b>402</b> - Missing parameter AppSid
     * <p><b>459</b> - Authentication parameters are incorrectly base64 encoded
     * @param appsid A character string that uniquely identifies your app
     * @param msg Message body supports both English and unicodes characters, concatenated messages is supported
     * @param to Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498)
     * @param sender The SenderID to send from, App default SenderID is used unless else stated
     * @param baseEncode Binary-to-text encoding schemes that represent binary data in an ASCII string format
     * @param encoding Converts information from a source into symbols for communication or storage, GSM7 for English and UCS2 for Arabic
     * @return SendWrapperresponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    private ResponseSpec postSendmessageRequestCreation(String appsid, String msg, Long to, String sender, Boolean baseEncode, String encoding) throws WebClientResponseException {
        Object postBody = null;
        // verify the required parameter 'appsid' is set
        if (appsid == null) {
            throw new WebClientResponseException("Missing the required parameter 'appsid' when calling postSendmessage", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // verify the required parameter 'msg' is set
        if (msg == null) {
            throw new WebClientResponseException("Missing the required parameter 'msg' when calling postSendmessage", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // verify the required parameter 'to' is set
        if (to == null) {
            throw new WebClientResponseException("Missing the required parameter 'to' when calling postSendmessage", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // verify the required parameter 'sender' is set
        if (sender == null) {
            throw new WebClientResponseException("Missing the required parameter 'sender' when calling postSendmessage", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // create path and map variables
        final Map<String, Object> pathParams = new HashMap<String, Object>();

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "appsid", appsid));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "msg", msg));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "to", to));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "sender", sender));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "baseEncode", baseEncode));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "encoding", encoding));

        final String[] localVarAccepts = { 
            "application/json"
        };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[] { "httpBasic" };

        ParameterizedTypeReference<SendWrapperresponse> localVarReturnType = new ParameterizedTypeReference<SendWrapperresponse>() {};
        return apiClient.invokeAPI("/wrapper/sendSMS.php", HttpMethod.POST, pathParams, queryParams, postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    }

    /**
     * Send message
     * Unifonic Send Wrapper API allows you to send  text messages to  multiple users at the same time
     * <p><b>200</b>
     * <p><b>401</b> - Authentication failed
     * <p><b>402</b> - Missing parameter AppSid
     * <p><b>459</b> - Authentication parameters are incorrectly base64 encoded
     * @param appsid A character string that uniquely identifies your app
     * @param msg Message body supports both English and unicodes characters, concatenated messages is supported
     * @param to Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498)
     * @param sender The SenderID to send from, App default SenderID is used unless else stated
     * @param baseEncode Binary-to-text encoding schemes that represent binary data in an ASCII string format
     * @param encoding Converts information from a source into symbols for communication or storage, GSM7 for English and UCS2 for Arabic
     * @return SendWrapperresponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<SendWrapperresponse> postSendmessage(String appsid, String msg, Long to, String sender, Boolean baseEncode, String encoding) throws WebClientResponseException {
        ParameterizedTypeReference<SendWrapperresponse> localVarReturnType = new ParameterizedTypeReference<SendWrapperresponse>() {};
        return postSendmessageRequestCreation(appsid, msg, to, sender, baseEncode, encoding).bodyToMono(localVarReturnType);
    }

    public Mono<ResponseEntity<SendWrapperresponse>> postSendmessageWithHttpInfo(String appsid, String msg, Long to, String sender, Boolean baseEncode, String encoding) throws WebClientResponseException {
        ParameterizedTypeReference<SendWrapperresponse> localVarReturnType = new ParameterizedTypeReference<SendWrapperresponse>() {};
        return postSendmessageRequestCreation(appsid, msg, to, sender, baseEncode, encoding).toEntity(localVarReturnType);
    }
}

package com.unifonic.api;

import com.unifonic.invoker.ApiClient;

import com.unifonic.model.GetMessagesDetailsresponse;
import com.unifonic.model.GetScheduledMessageresponse;
import java.time.LocalDate;
import com.unifonic.model.Sendresponse;
import com.unifonic.model.Sendscheduledmessagesresponse;
import com.unifonic.model.StopScheduledMessagesresponse;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Flux;

@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen", date = "2022-10-26T17:30:54.972311+01:00[Europe/London]")
public class RestApi {
    private ApiClient apiClient;

    public RestApi() {
        this(new ApiClient());
    }

    @Autowired
    public RestApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Get Message Details
     * Unifonic Get message details API allows you to get details of messages with optional filters,returns paginated messages, next page or previous page through simple RESTful APIs
     * <p><b>200</b>
     * <p><b>401</b> - Authentication failed
     * <p><b>432</b> - MessageId must be numeric
     * <p><b>599</b> - Request failed
     * @param appSid A character string that uniquely identifies your app
     * @param messageID A unique ID that identifies a message
     * @param senderID The SenderID to send from, App default SenderID is used unless else stated
     * @param recipient Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498)
     * @param dateFrom The start date for the report time interval, date format should be yyyy-mm-dd
     * @param dateTo The end date for the report time interval, date format should be yyyy-mm-dd
     * @param correlationID Is a unique identifier value that is attached to requests and messages
     * @param limit The maximum number of messages details
     * @param baseEncode Binary-to-text encoding schemes that represent binary data in an ASCII string format
     * @return GetMessagesDetailsresponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    private ResponseSpec getMessageDetailsRequestCreation(String appSid, Long messageID, String senderID, Long recipient, LocalDate dateFrom, LocalDate dateTo, String correlationID, Long limit, Boolean baseEncode) throws WebClientResponseException {
        Object postBody = null;
        // verify the required parameter 'appSid' is set
        if (appSid == null) {
            throw new WebClientResponseException("Missing the required parameter 'appSid' when calling getMessageDetails", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // create path and map variables
        final Map<String, Object> pathParams = new HashMap<String, Object>();

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "AppSid", appSid));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "MessageID", messageID));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "senderID", senderID));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "Recipient", recipient));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "dateFrom", dateFrom));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "dateTo", dateTo));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "CorrelationID", correlationID));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "Limit", limit));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "baseEncode", baseEncode));

        final String[] localVarAccepts = { 
            "application/json"
        };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[] { "httpBasic" };

        ParameterizedTypeReference<GetMessagesDetailsresponse> localVarReturnType = new ParameterizedTypeReference<GetMessagesDetailsresponse>() {};
        return apiClient.invokeAPI("/rest/SMS/Messages/GetMessagesDetails", HttpMethod.POST, pathParams, queryParams, postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    }

    /**
     * Get Message Details
     * Unifonic Get message details API allows you to get details of messages with optional filters,returns paginated messages, next page or previous page through simple RESTful APIs
     * <p><b>200</b>
     * <p><b>401</b> - Authentication failed
     * <p><b>432</b> - MessageId must be numeric
     * <p><b>599</b> - Request failed
     * @param appSid A character string that uniquely identifies your app
     * @param messageID A unique ID that identifies a message
     * @param senderID The SenderID to send from, App default SenderID is used unless else stated
     * @param recipient Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498)
     * @param dateFrom The start date for the report time interval, date format should be yyyy-mm-dd
     * @param dateTo The end date for the report time interval, date format should be yyyy-mm-dd
     * @param correlationID Is a unique identifier value that is attached to requests and messages
     * @param limit The maximum number of messages details
     * @param baseEncode Binary-to-text encoding schemes that represent binary data in an ASCII string format
     * @return GetMessagesDetailsresponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<GetMessagesDetailsresponse> getMessageDetails(String appSid, Long messageID, String senderID, Long recipient, LocalDate dateFrom, LocalDate dateTo, String correlationID, Long limit, Boolean baseEncode) throws WebClientResponseException {
        ParameterizedTypeReference<GetMessagesDetailsresponse> localVarReturnType = new ParameterizedTypeReference<GetMessagesDetailsresponse>() {};
        return getMessageDetailsRequestCreation(appSid, messageID, senderID, recipient, dateFrom, dateTo, correlationID, limit, baseEncode).bodyToMono(localVarReturnType);
    }

    public Mono<ResponseEntity<GetMessagesDetailsresponse>> getMessageDetailsWithHttpInfo(String appSid, Long messageID, String senderID, Long recipient, LocalDate dateFrom, LocalDate dateTo, String correlationID, Long limit, Boolean baseEncode) throws WebClientResponseException {
        ParameterizedTypeReference<GetMessagesDetailsresponse> localVarReturnType = new ParameterizedTypeReference<GetMessagesDetailsresponse>() {};
        return getMessageDetailsRequestCreation(appSid, messageID, senderID, recipient, dateFrom, dateTo, correlationID, limit, baseEncode).toEntity(localVarReturnType);
    }
    /**
     * Scheduled Message Details
     * Unifonic Scheduled message details allows you to get details of scheduled messages through simple RESTful APIs
     * <p><b>200</b>
     * <p><b>401</b> - Authentication failed
     * @param appSid A character string that uniquely identifies your app
     * @return GetScheduledMessageresponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    private ResponseSpec scheduledMessageDetailsRequestCreation(String appSid) throws WebClientResponseException {
        Object postBody = null;
        // verify the required parameter 'appSid' is set
        if (appSid == null) {
            throw new WebClientResponseException("Missing the required parameter 'appSid' when calling scheduledMessageDetails", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // create path and map variables
        final Map<String, Object> pathParams = new HashMap<String, Object>();

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "AppSid", appSid));

        final String[] localVarAccepts = { 
            "application/json"
        };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[] { "httpBasic" };

        ParameterizedTypeReference<GetScheduledMessageresponse> localVarReturnType = new ParameterizedTypeReference<GetScheduledMessageresponse>() {};
        return apiClient.invokeAPI("/rest/SMS/messages/scheduledmessages", HttpMethod.GET, pathParams, queryParams, postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    }

    /**
     * Scheduled Message Details
     * Unifonic Scheduled message details allows you to get details of scheduled messages through simple RESTful APIs
     * <p><b>200</b>
     * <p><b>401</b> - Authentication failed
     * @param appSid A character string that uniquely identifies your app
     * @return GetScheduledMessageresponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<GetScheduledMessageresponse> scheduledMessageDetails(String appSid) throws WebClientResponseException {
        ParameterizedTypeReference<GetScheduledMessageresponse> localVarReturnType = new ParameterizedTypeReference<GetScheduledMessageresponse>() {};
        return scheduledMessageDetailsRequestCreation(appSid).bodyToMono(localVarReturnType);
    }

    public Mono<ResponseEntity<GetScheduledMessageresponse>> scheduledMessageDetailsWithHttpInfo(String appSid) throws WebClientResponseException {
        ParameterizedTypeReference<GetScheduledMessageresponse> localVarReturnType = new ParameterizedTypeReference<GetScheduledMessageresponse>() {};
        return scheduledMessageDetailsRequestCreation(appSid).toEntity(localVarReturnType);
    }
    /**
     * Send Scheduled Messages
     * Unifonic Send Scheduled API allows you to schedule text messages to users around the globe through simple RESTful API to be sent in future.
     * <p><b>200</b>
     * <p><b>401</b> - Authentication failed
     * <p><b>406</b> - Wrong parameter format
     * <p><b>449</b> - Message body is empty
     * <p><b>451</b> - TimeScheduled parameter must indicate time in the future
     * <p><b>480</b> - This user cannot use specified SenderID
     * <p><b>482</b> - Invalid dest num
     * @param appSid A character string that uniquely identifies your app
     * @param senderID The SenderID to send from, App default SenderID is used unless else stated
     * @param recipient Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498)
     * @param body Message body supports both English and unicodes characters, concatenated messages is supported
     * @param timeScheduled Schedule send messages, in the following format yyyy-mm-dd HH:mm:ss
     * @param responseType Support json format only
     * @param correlationID Is a unique identifier value that is attached to requests and messages
     * @param baseEncode Binary-to-text encoding schemes that represent binary data in an ASCII string format
     * @return Sendscheduledmessagesresponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    private ResponseSpec sendScheduledMessagesRequestCreation(String appSid, String senderID, Long recipient, String body, String timeScheduled, String responseType, String correlationID, Boolean baseEncode) throws WebClientResponseException {
        Object postBody = null;
        // verify the required parameter 'appSid' is set
        if (appSid == null) {
            throw new WebClientResponseException("Missing the required parameter 'appSid' when calling sendScheduledMessages", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // verify the required parameter 'senderID' is set
        if (senderID == null) {
            throw new WebClientResponseException("Missing the required parameter 'senderID' when calling sendScheduledMessages", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // verify the required parameter 'recipient' is set
        if (recipient == null) {
            throw new WebClientResponseException("Missing the required parameter 'recipient' when calling sendScheduledMessages", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // verify the required parameter 'body' is set
        if (body == null) {
            throw new WebClientResponseException("Missing the required parameter 'body' when calling sendScheduledMessages", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // verify the required parameter 'timeScheduled' is set
        if (timeScheduled == null) {
            throw new WebClientResponseException("Missing the required parameter 'timeScheduled' when calling sendScheduledMessages", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // create path and map variables
        final Map<String, Object> pathParams = new HashMap<String, Object>();

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "AppSid", appSid));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "SenderID", senderID));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "Recipient", recipient));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "Body", body));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "TimeScheduled", timeScheduled));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "responseType", responseType));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "CorrelationID", correlationID));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "baseEncode", baseEncode));

        final String[] localVarAccepts = { 
            "application/json"
        };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[] { "httpBasic" };

        ParameterizedTypeReference<Sendscheduledmessagesresponse> localVarReturnType = new ParameterizedTypeReference<Sendscheduledmessagesresponse>() {};
        return apiClient.invokeAPI("/rest/SMS/messages/scheduledmessages", HttpMethod.POST, pathParams, queryParams, postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    }

    /**
     * Send Scheduled Messages
     * Unifonic Send Scheduled API allows you to schedule text messages to users around the globe through simple RESTful API to be sent in future.
     * <p><b>200</b>
     * <p><b>401</b> - Authentication failed
     * <p><b>406</b> - Wrong parameter format
     * <p><b>449</b> - Message body is empty
     * <p><b>451</b> - TimeScheduled parameter must indicate time in the future
     * <p><b>480</b> - This user cannot use specified SenderID
     * <p><b>482</b> - Invalid dest num
     * @param appSid A character string that uniquely identifies your app
     * @param senderID The SenderID to send from, App default SenderID is used unless else stated
     * @param recipient Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498)
     * @param body Message body supports both English and unicodes characters, concatenated messages is supported
     * @param timeScheduled Schedule send messages, in the following format yyyy-mm-dd HH:mm:ss
     * @param responseType Support json format only
     * @param correlationID Is a unique identifier value that is attached to requests and messages
     * @param baseEncode Binary-to-text encoding schemes that represent binary data in an ASCII string format
     * @return Sendscheduledmessagesresponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<Sendscheduledmessagesresponse> sendScheduledMessages(String appSid, String senderID, Long recipient, String body, String timeScheduled, String responseType, String correlationID, Boolean baseEncode) throws WebClientResponseException {
        ParameterizedTypeReference<Sendscheduledmessagesresponse> localVarReturnType = new ParameterizedTypeReference<Sendscheduledmessagesresponse>() {};
        return sendScheduledMessagesRequestCreation(appSid, senderID, recipient, body, timeScheduled, responseType, correlationID, baseEncode).bodyToMono(localVarReturnType);
    }

    public Mono<ResponseEntity<Sendscheduledmessagesresponse>> sendScheduledMessagesWithHttpInfo(String appSid, String senderID, Long recipient, String body, String timeScheduled, String responseType, String correlationID, Boolean baseEncode) throws WebClientResponseException {
        ParameterizedTypeReference<Sendscheduledmessagesresponse> localVarReturnType = new ParameterizedTypeReference<Sendscheduledmessagesresponse>() {};
        return sendScheduledMessagesRequestCreation(appSid, senderID, recipient, body, timeScheduled, responseType, correlationID, baseEncode).toEntity(localVarReturnType);
    }
    /**
     * Send message
     * Unifonic Send API allows you to send  text messages to users around the globe through simple RESTful APIs
     * <p><b>200</b>
     * <p><b>401</b> - Authentication failed
     * <p><b>449</b> - Message body is empty
     * <p><b>480</b> - This user cannot use specified SenderID
     * <p><b>482</b> - Invalid dest num
     * @param appSid A character string that uniquely identifies your app
     * @param senderID The SenderID to send from, App default SenderID is used unless else stated
     * @param body Message body supports both English and unicodes characters, concatenated messages is supported
     * @param recipient Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498)
     * @param responseType Support json format only
     * @param correlationID Is a unique identifier value that is attached to requests and messages
     * @param baseEncode Binary-to-text encoding schemes that represent binary data in an ASCII string format
     * @param statusCallback Filter messages report according to a specific message status, \&quot;Sent\&quot;, \&quot;Queued\&quot;, \&quot;Rejected\&quot; or \&quot;Failed
     * @param async It specifies that the request will be executed asynchronously as soon as it is sent
     * @return Sendresponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    private ResponseSpec sendmessageRequestCreation(String appSid, String senderID, String body, Long recipient, String responseType, String correlationID, Boolean baseEncode, String statusCallback, Boolean async) throws WebClientResponseException {
        Object postBody = null;
        // verify the required parameter 'appSid' is set
        if (appSid == null) {
            throw new WebClientResponseException("Missing the required parameter 'appSid' when calling sendmessage", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // verify the required parameter 'senderID' is set
        if (senderID == null) {
            throw new WebClientResponseException("Missing the required parameter 'senderID' when calling sendmessage", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // verify the required parameter 'body' is set
        if (body == null) {
            throw new WebClientResponseException("Missing the required parameter 'body' when calling sendmessage", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // verify the required parameter 'recipient' is set
        if (recipient == null) {
            throw new WebClientResponseException("Missing the required parameter 'recipient' when calling sendmessage", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // create path and map variables
        final Map<String, Object> pathParams = new HashMap<String, Object>();

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "AppSid", appSid));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "SenderID", senderID));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "Body", body));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "Recipient", recipient));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "responseType", responseType));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "CorrelationID", correlationID));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "baseEncode", baseEncode));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "statusCallback", statusCallback));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "async", async));

        final String[] localVarAccepts = { 
            "application/json"
        };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[] { "httpBasic" };

        ParameterizedTypeReference<Sendresponse> localVarReturnType = new ParameterizedTypeReference<Sendresponse>() {};
        return apiClient.invokeAPI("/rest/SMS/messages", HttpMethod.POST, pathParams, queryParams, postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    }

    /**
     * Send message
     * Unifonic Send API allows you to send  text messages to users around the globe through simple RESTful APIs
     * <p><b>200</b>
     * <p><b>401</b> - Authentication failed
     * <p><b>449</b> - Message body is empty
     * <p><b>480</b> - This user cannot use specified SenderID
     * <p><b>482</b> - Invalid dest num
     * @param appSid A character string that uniquely identifies your app
     * @param senderID The SenderID to send from, App default SenderID is used unless else stated
     * @param body Message body supports both English and unicodes characters, concatenated messages is supported
     * @param recipient Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498)
     * @param responseType Support json format only
     * @param correlationID Is a unique identifier value that is attached to requests and messages
     * @param baseEncode Binary-to-text encoding schemes that represent binary data in an ASCII string format
     * @param statusCallback Filter messages report according to a specific message status, \&quot;Sent\&quot;, \&quot;Queued\&quot;, \&quot;Rejected\&quot; or \&quot;Failed
     * @param async It specifies that the request will be executed asynchronously as soon as it is sent
     * @return Sendresponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<Sendresponse> sendmessage(String appSid, String senderID, String body, Long recipient, String responseType, String correlationID, Boolean baseEncode, String statusCallback, Boolean async) throws WebClientResponseException {
        ParameterizedTypeReference<Sendresponse> localVarReturnType = new ParameterizedTypeReference<Sendresponse>() {};
        return sendmessageRequestCreation(appSid, senderID, body, recipient, responseType, correlationID, baseEncode, statusCallback, async).bodyToMono(localVarReturnType);
    }

    public Mono<ResponseEntity<Sendresponse>> sendmessageWithHttpInfo(String appSid, String senderID, String body, Long recipient, String responseType, String correlationID, Boolean baseEncode, String statusCallback, Boolean async) throws WebClientResponseException {
        ParameterizedTypeReference<Sendresponse> localVarReturnType = new ParameterizedTypeReference<Sendresponse>() {};
        return sendmessageRequestCreation(appSid, senderID, body, recipient, responseType, correlationID, baseEncode, statusCallback, async).toEntity(localVarReturnType);
    }
    /**
     * Stop Scheduled Messages
     * Unifonic Stop scheduled messages API allows you to Delete (Stops) scheduled message,If MessageID is specified only one message is stopped, Otherwise all messages are stopped through simple RESTful APIs.
     * <p><b>200</b>
     * <p><b>401</b> - Authentication failed
     * <p><b>455</b> - Scheduled message not found for this User
     * @param appSid A character string that uniquely identifies your app
     * @param messageID A unique ID that identifies a message
     * @param responseFormat support json format only
     * @param baseEncode Binary-to-text encoding schemes that represent binary data in an ASCII string format
     * @return StopScheduledMessagesresponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    private ResponseSpec stopScheduledMessagesRequestCreation(String appSid, Long messageID, String responseFormat, Boolean baseEncode) throws WebClientResponseException {
        Object postBody = null;
        // verify the required parameter 'appSid' is set
        if (appSid == null) {
            throw new WebClientResponseException("Missing the required parameter 'appSid' when calling stopScheduledMessages", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // create path and map variables
        final Map<String, Object> pathParams = new HashMap<String, Object>();

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "AppSid", appSid));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "MessageID", messageID));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "responseFormat", responseFormat));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "baseEncode", baseEncode));

        final String[] localVarAccepts = { 
            "application/json"
        };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[] { "httpBasic" };

        ParameterizedTypeReference<StopScheduledMessagesresponse> localVarReturnType = new ParameterizedTypeReference<StopScheduledMessagesresponse>() {};
        return apiClient.invokeAPI("/rest/SMS/messages/scheduledmessages", HttpMethod.DELETE, pathParams, queryParams, postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    }

    /**
     * Stop Scheduled Messages
     * Unifonic Stop scheduled messages API allows you to Delete (Stops) scheduled message,If MessageID is specified only one message is stopped, Otherwise all messages are stopped through simple RESTful APIs.
     * <p><b>200</b>
     * <p><b>401</b> - Authentication failed
     * <p><b>455</b> - Scheduled message not found for this User
     * @param appSid A character string that uniquely identifies your app
     * @param messageID A unique ID that identifies a message
     * @param responseFormat support json format only
     * @param baseEncode Binary-to-text encoding schemes that represent binary data in an ASCII string format
     * @return StopScheduledMessagesresponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<StopScheduledMessagesresponse> stopScheduledMessages(String appSid, Long messageID, String responseFormat, Boolean baseEncode) throws WebClientResponseException {
        ParameterizedTypeReference<StopScheduledMessagesresponse> localVarReturnType = new ParameterizedTypeReference<StopScheduledMessagesresponse>() {};
        return stopScheduledMessagesRequestCreation(appSid, messageID, responseFormat, baseEncode).bodyToMono(localVarReturnType);
    }

    public Mono<ResponseEntity<StopScheduledMessagesresponse>> stopScheduledMessagesWithHttpInfo(String appSid, Long messageID, String responseFormat, Boolean baseEncode) throws WebClientResponseException {
        ParameterizedTypeReference<StopScheduledMessagesresponse> localVarReturnType = new ParameterizedTypeReference<StopScheduledMessagesresponse>() {};
        return stopScheduledMessagesRequestCreation(appSid, messageID, responseFormat, baseEncode).toEntity(localVarReturnType);
    }
}

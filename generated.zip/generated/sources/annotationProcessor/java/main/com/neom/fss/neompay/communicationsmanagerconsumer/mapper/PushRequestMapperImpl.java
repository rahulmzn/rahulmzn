package com.neom.fss.neompay.communicationsmanagerconsumer.mapper;

import com.neom.fss.neompay.communicationsmanager.PushRequestOuterClass.PushRequest;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.PushNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.PushNotificationDetails.PushNotificationDetailsBuilder;
import javax.annotation.processing.Generated;
import org.springframework.stereotype.Component;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2022-10-26T17:31:02+0100",
    comments = "version: 1.4.2.Final, compiler: IncrementalProcessingEnvironment from gradle-language-java-7.2.jar, environment: Java 11.0.12 (Homebrew)"
)
@Component
public class PushRequestMapperImpl implements PushRequestMapper {

    @Override
    public PushNotificationDetails map(PushRequest request) {
        if ( request == null ) {
            return null;
        }

        PushNotificationDetailsBuilder pushNotificationDetails = PushNotificationDetails.builder();

        pushNotificationDetails.to( request.getPushNotificationDetailsOrBuilder().getToList() );
        pushNotificationDetails.deviceType( request.getPushNotificationDetailsOrBuilder().getDeviceType() );
        pushNotificationDetails.messageBody( request.getPushNotificationDetailsOrBuilder().getMessageBody() );
        pushNotificationDetails.title( request.getPushNotificationDetailsOrBuilder().getTitle() );
        pushNotificationDetails.deepLinkUrl( request.getPushNotificationDetailsOrBuilder().getDeepLinkUrl() );

        return pushNotificationDetails.build();
    }
}

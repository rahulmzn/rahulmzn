package com.neom.fss.neompay.communicationsmanagerconsumer.mapper;

import com.neom.fss.neompay.communicationsmanager.SmsRequest.SMSRequest;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.SmsNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.SmsNotificationDetails.SmsNotificationDetailsBuilder;
import javax.annotation.processing.Generated;
import org.springframework.stereotype.Component;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2022-10-26T17:31:02+0100",
    comments = "version: 1.4.2.Final, compiler: IncrementalProcessingEnvironment from gradle-language-java-7.2.jar, environment: Java 11.0.12 (Homebrew)"
)
@Component
public class SmsRequestMapperImpl implements SmsRequestMapper {

    @Override
    public SmsNotificationDetails map(SMSRequest request) {
        if ( request == null ) {
            return null;
        }

        SmsNotificationDetailsBuilder smsNotificationDetails = SmsNotificationDetails.builder();

        smsNotificationDetails.to( mapListMobile(request.getSmsNotificationDetailsOrBuilder().getToList()) );
        smsNotificationDetails.messageBody( mapEmptyString(request.getSmsNotificationDetailsOrBuilder().getMessageBody()) );

        return smsNotificationDetails.build();
    }
}

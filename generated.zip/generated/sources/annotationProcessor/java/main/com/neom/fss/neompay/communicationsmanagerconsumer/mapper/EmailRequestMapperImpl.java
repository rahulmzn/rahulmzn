package com.neom.fss.neompay.communicationsmanagerconsumer.mapper;

import com.neom.fss.neompay.communicationsmanager.EmailRequestOuterClass.EmailRequest;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.EmailNotificationDetails;
import com.neom.fss.neompay.communicationsmanagerconsumer.model.EmailNotificationDetails.EmailNotificationDetailsBuilder;
import javax.annotation.processing.Generated;
import org.springframework.stereotype.Component;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2022-10-26T17:31:02+0100",
    comments = "version: 1.4.2.Final, compiler: IncrementalProcessingEnvironment from gradle-language-java-7.2.jar, environment: Java 11.0.12 (Homebrew)"
)
@Component
public class EmailRequestMapperImpl implements EmailRequestMapper {

    @Override
    public EmailNotificationDetails map(EmailRequest request) {
        if ( request == null ) {
            return null;
        }

        EmailNotificationDetailsBuilder emailNotificationDetails = EmailNotificationDetails.builder();

        emailNotificationDetails.to( mapListEmail(request.getEmailNotificationDetailsOrBuilder().getToList()) );
        emailNotificationDetails.cc( mapListEmail(request.getEmailNotificationDetailsOrBuilder().getCcList()) );
        emailNotificationDetails.messageBody( mapEmptyString(request.getEmailNotificationDetailsOrBuilder().getMessageBody()) );
        emailNotificationDetails.subject( mapEmptyString(request.getEmailNotificationDetailsOrBuilder().getSubject()) );

        return emailNotificationDetails.build();
    }
}

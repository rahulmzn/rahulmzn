# WrapperApi

All URIs are relative to *http://el.cloud.unifonic.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getmsgQuery**](WrapperApi.md#getmsgQuery) | **POST** /wrapper/msgQuery | Get msgQuery
[**postSendmessage**](WrapperApi.md#postSendmessage) | **POST** /wrapper/sendSMS.php | Send message



## getmsgQuery

> GetMessageQueryresponse getmsgQuery(appsid, msgid, to)

Get msgQuery

Unifonic Get message query API allows you to get details of specified message.

### Example

```java
// Import classes:
import com.unifonic.invoker.ApiClient;
import com.unifonic.invoker.ApiException;
import com.unifonic.invoker.Configuration;
import com.unifonic.invoker.auth.*;
import com.unifonic.invoker.models.*;
import com.unifonic.api.WrapperApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("http://el.cloud.unifonic.com");
        
        // Configure HTTP basic authorization: httpBasic
        HttpBasicAuth httpBasic = (HttpBasicAuth) defaultClient.getAuthentication("httpBasic");
        httpBasic.setUsername("YOUR USERNAME");
        httpBasic.setPassword("YOUR PASSWORD");

        WrapperApi apiInstance = new WrapperApi(defaultClient);
        String appsid = " Use your own appsid"; // String | A character string that uniquely identifies your app
        Long msgid = 3200017901931L; // Long | A unique ID that identifies a message
        Long to = 966505980169L; // Long | Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498)
        try {
            GetMessageQueryresponse result = apiInstance.getmsgQuery(appsid, msgid, to);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling WrapperApi#getmsgQuery");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **appsid** | **String**| A character string that uniquely identifies your app |
 **msgid** | **Long**| A unique ID that identifies a message |
 **to** | **Long**| Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498) | [optional]

### Return type

[**GetMessageQueryresponse**](GetMessageQueryresponse.md)

### Authorization

[httpBasic](../README.md#httpBasic)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** |  |  -  |
| **401** | Authentication failed |  -  |
| **402** | Missing parameter AppSid |  -  |
| **432** | MessageId must be numeric |  -  |
| **452** | User must specify either messageId or recipient parameter |  -  |


## postSendmessage

> SendWrapperresponse postSendmessage(appsid, msg, to, sender, baseEncode, encoding)

Send message

Unifonic Send Wrapper API allows you to send  text messages to  multiple users at the same time

### Example

```java
// Import classes:
import com.unifonic.invoker.ApiClient;
import com.unifonic.invoker.ApiException;
import com.unifonic.invoker.Configuration;
import com.unifonic.invoker.auth.*;
import com.unifonic.invoker.models.*;
import com.unifonic.api.WrapperApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("http://el.cloud.unifonic.com");
        
        // Configure HTTP basic authorization: httpBasic
        HttpBasicAuth httpBasic = (HttpBasicAuth) defaultClient.getAuthentication("httpBasic");
        httpBasic.setUsername("YOUR USERNAME");
        httpBasic.setPassword("YOUR PASSWORD");

        WrapperApi apiInstance = new WrapperApi(defaultClient);
        String appsid = "Use your own appsid"; // String | A character string that uniquely identifies your app
        String msg = "Test"; // String | Message body supports both English and unicodes characters, concatenated messages is supported
        Long to = 966505980169L; // Long | Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498)
        String sender = "sender"; // String | The SenderID to send from, App default SenderID is used unless else stated
        Boolean baseEncode = false; // Boolean | Binary-to-text encoding schemes that represent binary data in an ASCII string format
        String encoding = "UCS2"; // String | Converts information from a source into symbols for communication or storage, GSM7 for English and UCS2 for Arabic
        try {
            SendWrapperresponse result = apiInstance.postSendmessage(appsid, msg, to, sender, baseEncode, encoding);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling WrapperApi#postSendmessage");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **appsid** | **String**| A character string that uniquely identifies your app |
 **msg** | **String**| Message body supports both English and unicodes characters, concatenated messages is supported |
 **to** | **Long**| Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498) |
 **sender** | **String**| The SenderID to send from, App default SenderID is used unless else stated |
 **baseEncode** | **Boolean**| Binary-to-text encoding schemes that represent binary data in an ASCII string format | [optional] [default to false]
 **encoding** | **String**| Converts information from a source into symbols for communication or storage, GSM7 for English and UCS2 for Arabic | [optional] [default to UCS2]

### Return type

[**SendWrapperresponse**](SendWrapperresponse.md)

### Authorization

[httpBasic](../README.md#httpBasic)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** |  |  -  |
| **401** | Authentication failed |  -  |
| **402** | Missing parameter AppSid |  -  |
| **459** | Authentication parameters are incorrectly base64 encoded |  -  |


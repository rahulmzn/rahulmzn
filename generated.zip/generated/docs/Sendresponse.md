

# Sendresponse

Sends one message.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **String** | The message sent successfully | 
**message** | **String** | The Error message if its false, Null if its true | 
**errorCode** | **String** | The error code if there is any | 
**data** | **Object** | Message id, Time created, correlation id., status, number of units, cost, balance, Recipient | 




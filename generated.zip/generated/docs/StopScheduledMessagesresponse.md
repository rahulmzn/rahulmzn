

# StopScheduledMessagesresponse

Delete (Stops) scheduled message,If MessageID is specified, only one message is stopped.  Otherwise all messages are stopped

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **String** | The request sent successfully | 
**message** | **String** | The Error message if its false, Null if its true | 
**errorCode** | **String** | Error Code if there is an error | 
**data** | **Object** | Message id, Time created, correlation id., status, number of units, cost, balance, Recipient | 




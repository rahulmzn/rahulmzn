

# SendWrapperresponse

Sends message to one or more recipients.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** | The default error code | 
**messageID** | **String** | A unique ID that identifies a message | 




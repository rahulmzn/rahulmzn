

# GetMessagesDetailsresponse

Gets details of messages with optional filters. Returns paginated messages, next page or previous page

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **Boolean** | The request sent successfully | 
**message** | **String** | The Error message if its false, Null if its true | 
**errorCode** | **String** | the error code if there is any | 
**data** | **Object** | Message id, Time created, correlation id., status, number of units, cost, balance, Recipient | 




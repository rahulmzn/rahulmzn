# RestApi

All URIs are relative to *http://el.cloud.unifonic.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getMessageDetails**](RestApi.md#getMessageDetails) | **POST** /rest/SMS/Messages/GetMessagesDetails | Get Message Details
[**scheduledMessageDetails**](RestApi.md#scheduledMessageDetails) | **GET** /rest/SMS/messages/scheduledmessages | Scheduled Message Details
[**sendScheduledMessages**](RestApi.md#sendScheduledMessages) | **POST** /rest/SMS/messages/scheduledmessages | Send Scheduled Messages
[**sendmessage**](RestApi.md#sendmessage) | **POST** /rest/SMS/messages | Send message
[**stopScheduledMessages**](RestApi.md#stopScheduledMessages) | **DELETE** /rest/SMS/messages/scheduledmessages | Stop Scheduled Messages



## getMessageDetails

> GetMessagesDetailsresponse getMessageDetails(appSid, messageID, senderID, recipient, dateFrom, dateTo, correlationID, limit, baseEncode)

Get Message Details

Unifonic Get message details API allows you to get details of messages with optional filters,returns paginated messages, next page or previous page through simple RESTful APIs

### Example

```java
// Import classes:
import com.unifonic.invoker.ApiClient;
import com.unifonic.invoker.ApiException;
import com.unifonic.invoker.Configuration;
import com.unifonic.invoker.auth.*;
import com.unifonic.invoker.models.*;
import com.unifonic.api.RestApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("http://el.cloud.unifonic.com");
        
        // Configure HTTP basic authorization: httpBasic
        HttpBasicAuth httpBasic = (HttpBasicAuth) defaultClient.getAuthentication("httpBasic");
        httpBasic.setUsername("YOUR USERNAME");
        httpBasic.setPassword("YOUR PASSWORD");

        RestApi apiInstance = new RestApi(defaultClient);
        String appSid = "Use your own AppSid"; // String | A character string that uniquely identifies your app
        Long messageID = 3200017891630L; // Long | A unique ID that identifies a message
        String senderID = "sender"; // String | The SenderID to send from, App default SenderID is used unless else stated
        Long recipient = 966505980169L; // Long | Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498)
        LocalDate dateFrom = LocalDate.parse("Thu Apr 12 01:00:00 BST 2018"); // LocalDate | The start date for the report time interval, date format should be yyyy-mm-dd
        LocalDate dateTo = LocalDate.parse("Sat May 12 01:00:00 BST 2018"); // LocalDate | The end date for the report time interval, date format should be yyyy-mm-dd
        String correlationID = "CorrrelationID"; // String | Is a unique identifier value that is attached to requests and messages
        Long limit = 20L; // Long | The maximum number of messages details
        Boolean baseEncode = true; // Boolean | Binary-to-text encoding schemes that represent binary data in an ASCII string format
        try {
            GetMessagesDetailsresponse result = apiInstance.getMessageDetails(appSid, messageID, senderID, recipient, dateFrom, dateTo, correlationID, limit, baseEncode);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling RestApi#getMessageDetails");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **appSid** | **String**| A character string that uniquely identifies your app |
 **messageID** | **Long**| A unique ID that identifies a message | [optional]
 **senderID** | **String**| The SenderID to send from, App default SenderID is used unless else stated | [optional]
 **recipient** | **Long**| Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498) | [optional]
 **dateFrom** | **LocalDate**| The start date for the report time interval, date format should be yyyy-mm-dd | [optional]
 **dateTo** | **LocalDate**| The end date for the report time interval, date format should be yyyy-mm-dd | [optional]
 **correlationID** | **String**| Is a unique identifier value that is attached to requests and messages | [optional]
 **limit** | **Long**| The maximum number of messages details | [optional]
 **baseEncode** | **Boolean**| Binary-to-text encoding schemes that represent binary data in an ASCII string format | [optional]

### Return type

[**GetMessagesDetailsresponse**](GetMessagesDetailsresponse.md)

### Authorization

[httpBasic](../README.md#httpBasic)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** |  |  -  |
| **401** | Authentication failed |  -  |
| **432** | MessageId must be numeric |  -  |
| **599** | Request failed |  -  |


## scheduledMessageDetails

> GetScheduledMessageresponse scheduledMessageDetails(appSid)

Scheduled Message Details

Unifonic Scheduled message details allows you to get details of scheduled messages through simple RESTful APIs

### Example

```java
// Import classes:
import com.unifonic.invoker.ApiClient;
import com.unifonic.invoker.ApiException;
import com.unifonic.invoker.Configuration;
import com.unifonic.invoker.auth.*;
import com.unifonic.invoker.models.*;
import com.unifonic.api.RestApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("http://el.cloud.unifonic.com");
        
        // Configure HTTP basic authorization: httpBasic
        HttpBasicAuth httpBasic = (HttpBasicAuth) defaultClient.getAuthentication("httpBasic");
        httpBasic.setUsername("YOUR USERNAME");
        httpBasic.setPassword("YOUR PASSWORD");

        RestApi apiInstance = new RestApi(defaultClient);
        String appSid = "Use your own AppSid"; // String | A character string that uniquely identifies your app
        try {
            GetScheduledMessageresponse result = apiInstance.scheduledMessageDetails(appSid);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling RestApi#scheduledMessageDetails");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **appSid** | **String**| A character string that uniquely identifies your app |

### Return type

[**GetScheduledMessageresponse**](GetScheduledMessageresponse.md)

### Authorization

[httpBasic](../README.md#httpBasic)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** |  |  -  |
| **401** | Authentication failed |  -  |


## sendScheduledMessages

> Sendscheduledmessagesresponse sendScheduledMessages(appSid, senderID, recipient, body, timeScheduled, responseType, correlationID, baseEncode)

Send Scheduled Messages

Unifonic Send Scheduled API allows you to schedule text messages to users around the globe through simple RESTful API to be sent in future.

### Example

```java
// Import classes:
import com.unifonic.invoker.ApiClient;
import com.unifonic.invoker.ApiException;
import com.unifonic.invoker.Configuration;
import com.unifonic.invoker.auth.*;
import com.unifonic.invoker.models.*;
import com.unifonic.api.RestApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("http://el.cloud.unifonic.com");
        
        // Configure HTTP basic authorization: httpBasic
        HttpBasicAuth httpBasic = (HttpBasicAuth) defaultClient.getAuthentication("httpBasic");
        httpBasic.setUsername("YOUR USERNAME");
        httpBasic.setPassword("YOUR PASSWORD");

        RestApi apiInstance = new RestApi(defaultClient);
        String appSid = "Use your own AppSid"; // String | A character string that uniquely identifies your app
        String senderID = "sender"; // String | The SenderID to send from, App default SenderID is used unless else stated
        Long recipient = 966505980169L; // Long | Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498)
        String body = "Test"; // String | Message body supports both English and unicodes characters, concatenated messages is supported
        String timeScheduled = "Sun, 12 Apr 2020 11:53:00 GMT"; // String | Schedule send messages, in the following format yyyy-mm-dd HH:mm:ss
        String responseType = "Json"; // String | Support json format only
        String correlationID = "CorrelationID"; // String | Is a unique identifier value that is attached to requests and messages
        Boolean baseEncode = true; // Boolean | Binary-to-text encoding schemes that represent binary data in an ASCII string format
        try {
            Sendscheduledmessagesresponse result = apiInstance.sendScheduledMessages(appSid, senderID, recipient, body, timeScheduled, responseType, correlationID, baseEncode);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling RestApi#sendScheduledMessages");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **appSid** | **String**| A character string that uniquely identifies your app |
 **senderID** | **String**| The SenderID to send from, App default SenderID is used unless else stated |
 **recipient** | **Long**| Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498) |
 **body** | **String**| Message body supports both English and unicodes characters, concatenated messages is supported |
 **timeScheduled** | **String**| Schedule send messages, in the following format yyyy-mm-dd HH:mm:ss |
 **responseType** | **String**| Support json format only | [optional]
 **correlationID** | **String**| Is a unique identifier value that is attached to requests and messages | [optional]
 **baseEncode** | **Boolean**| Binary-to-text encoding schemes that represent binary data in an ASCII string format | [optional]

### Return type

[**Sendscheduledmessagesresponse**](Sendscheduledmessagesresponse.md)

### Authorization

[httpBasic](../README.md#httpBasic)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** |  |  -  |
| **401** | Authentication failed |  -  |
| **406** | Wrong parameter format |  -  |
| **449** | Message body is empty |  -  |
| **451** | TimeScheduled parameter must indicate time in the future |  -  |
| **480** | This user cannot use specified SenderID |  -  |
| **482** | Invalid dest num |  -  |


## sendmessage

> Sendresponse sendmessage(appSid, senderID, body, recipient, responseType, correlationID, baseEncode, statusCallback, async)

Send message

Unifonic Send API allows you to send  text messages to users around the globe through simple RESTful APIs

### Example

```java
// Import classes:
import com.unifonic.invoker.ApiClient;
import com.unifonic.invoker.ApiException;
import com.unifonic.invoker.Configuration;
import com.unifonic.invoker.auth.*;
import com.unifonic.invoker.models.*;
import com.unifonic.api.RestApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("http://el.cloud.unifonic.com");
        
        // Configure HTTP basic authorization: httpBasic
        HttpBasicAuth httpBasic = (HttpBasicAuth) defaultClient.getAuthentication("httpBasic");
        httpBasic.setUsername("YOUR USERNAME");
        httpBasic.setPassword("YOUR PASSWORD");

        RestApi apiInstance = new RestApi(defaultClient);
        String appSid = "Use your own AppSid"; // String | A character string that uniquely identifies your app
        String senderID = "sender"; // String | The SenderID to send from, App default SenderID is used unless else stated
        String body = "Test"; // String | Message body supports both English and unicodes characters, concatenated messages is supported
        Long recipient = 966505980169L; // Long | Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498)
        String responseType = "JSON"; // String | Support json format only
        String correlationID = "CorrelationID"; // String | Is a unique identifier value that is attached to requests and messages
        Boolean baseEncode = true; // Boolean | Binary-to-text encoding schemes that represent binary data in an ASCII string format
        String statusCallback = "sent"; // String | Filter messages report according to a specific message status, \"Sent\", \"Queued\", \"Rejected\" or \"Failed
        Boolean async = false; // Boolean | It specifies that the request will be executed asynchronously as soon as it is sent
        try {
            Sendresponse result = apiInstance.sendmessage(appSid, senderID, body, recipient, responseType, correlationID, baseEncode, statusCallback, async);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling RestApi#sendmessage");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **appSid** | **String**| A character string that uniquely identifies your app |
 **senderID** | **String**| The SenderID to send from, App default SenderID is used unless else stated |
 **body** | **String**| Message body supports both English and unicodes characters, concatenated messages is supported |
 **recipient** | **Long**| Destination mobile number, mobile numbers must be in international format without 00 or + Example: (4452023498) |
 **responseType** | **String**| Support json format only | [optional]
 **correlationID** | **String**| Is a unique identifier value that is attached to requests and messages | [optional]
 **baseEncode** | **Boolean**| Binary-to-text encoding schemes that represent binary data in an ASCII string format | [optional]
 **statusCallback** | **String**| Filter messages report according to a specific message status, \&quot;Sent\&quot;, \&quot;Queued\&quot;, \&quot;Rejected\&quot; or \&quot;Failed | [optional]
 **async** | **Boolean**| It specifies that the request will be executed asynchronously as soon as it is sent | [optional] [default to false]

### Return type

[**Sendresponse**](Sendresponse.md)

### Authorization

[httpBasic](../README.md#httpBasic)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** |  |  -  |
| **401** | Authentication failed |  -  |
| **449** | Message body is empty |  -  |
| **480** | This user cannot use specified SenderID |  -  |
| **482** | Invalid dest num |  -  |


## stopScheduledMessages

> StopScheduledMessagesresponse stopScheduledMessages(appSid, messageID, responseFormat, baseEncode)

Stop Scheduled Messages

Unifonic Stop scheduled messages API allows you to Delete (Stops) scheduled message,If MessageID is specified only one message is stopped, Otherwise all messages are stopped through simple RESTful APIs.

### Example

```java
// Import classes:
import com.unifonic.invoker.ApiClient;
import com.unifonic.invoker.ApiException;
import com.unifonic.invoker.Configuration;
import com.unifonic.invoker.auth.*;
import com.unifonic.invoker.models.*;
import com.unifonic.api.RestApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("http://el.cloud.unifonic.com");
        
        // Configure HTTP basic authorization: httpBasic
        HttpBasicAuth httpBasic = (HttpBasicAuth) defaultClient.getAuthentication("httpBasic");
        httpBasic.setUsername("YOUR USERNAME");
        httpBasic.setPassword("YOUR PASSWORD");

        RestApi apiInstance = new RestApi(defaultClient);
        String appSid = "Use your own AppSid"; // String | A character string that uniquely identifies your app
        Long messageID = 3200017891896L; // Long | A unique ID that identifies a message
        String responseFormat = "json"; // String | support json format only
        Boolean baseEncode = true; // Boolean | Binary-to-text encoding schemes that represent binary data in an ASCII string format
        try {
            StopScheduledMessagesresponse result = apiInstance.stopScheduledMessages(appSid, messageID, responseFormat, baseEncode);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling RestApi#stopScheduledMessages");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **appSid** | **String**| A character string that uniquely identifies your app |
 **messageID** | **Long**| A unique ID that identifies a message | [optional]
 **responseFormat** | **String**| support json format only | [optional]
 **baseEncode** | **Boolean**| Binary-to-text encoding schemes that represent binary data in an ASCII string format | [optional]

### Return type

[**StopScheduledMessagesresponse**](StopScheduledMessagesresponse.md)

### Authorization

[httpBasic](../README.md#httpBasic)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** |  |  -  |
| **401** | Authentication failed |  -  |
| **455** | Scheduled message not found for this User |  -  |


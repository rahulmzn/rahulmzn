

# GetScheduledMessageresponse

GetsDetails of specified scheduled message, If MessageID is specified, only one message is returned,Otherwise all messages(paginated) are queried.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **Boolean** | The request sent successfully | 
**message** | **String** | The Error message if its false, Null if its true | 
**errorCode** | **String** | the error code if there is any | 
**data** | **Object** | Message id, Time created, correlation id., status, number of units, cost, balance, Recipient | 




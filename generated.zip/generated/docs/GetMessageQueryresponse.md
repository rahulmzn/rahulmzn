

# GetMessageQueryresponse

Gets details of specified message

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**STATUS05** | **String** | The message statues | 






# Sendscheduledmessagesresponse

Schedules one message to be sent in the future.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **Boolean** | The request sent successfully | 
**message** | **String** | The Error message if its false, Null if its true | 
**errorCode** | **String** | The error code if there is any | 
**status** | **String** | Accepted or Rejected | 




# Introduction 
LBG Boiler plate template to define Microservice  

# Getting Started
To start implementing new microservice follow below steps.

1.	Define Api definition under contract interface package
2.	Implement controller based on contract interface
3.	Apply required business logic for microservice based on exposed API under service package and required class.

# Build and Test
1.	./gradlew clean
2.	./gradlew build
3.	./gradlew bootRun


function fn(max) {
    return Math.floor(Math.random() * max);
}

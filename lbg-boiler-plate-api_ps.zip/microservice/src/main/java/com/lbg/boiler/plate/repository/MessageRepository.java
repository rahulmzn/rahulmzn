package com.lbg.boiler.plate.repository;

import com.lbg.boiler.plate.repository.entity.Message;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageRepository extends JpaRepository<Message, Long> {
    Optional<Message> findByMessageId(String messageId);
}

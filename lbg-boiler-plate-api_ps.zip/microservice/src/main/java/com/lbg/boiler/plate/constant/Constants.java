package com.lbg.boiler.plate.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public enum Constants {

    HELLO("Hello","Hello ", "Constant description to represent Hello");

    private String name;
    private String value;
    private String description;
}

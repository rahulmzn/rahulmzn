package com.lbg.boiler.plate.service;

import com.lbg.boiler.plate.constant.Constants;
import com.lbg.cross.cutting.exception.ServiceException.BadInput;
import org.springframework.stereotype.Service;

/**
 * please add required java docs for service
 */
@Service
public class SayHelloWorldService implements HelloWorldService {

    /**
     * @param message : Message for world
     * @return Message
     */
    @Override
    public String sayHello(String message) {
        if(message.startsWith("error")){
            throw new BadInput("");
        }
        return Constants.HELLO.getValue() + message;
    }
}


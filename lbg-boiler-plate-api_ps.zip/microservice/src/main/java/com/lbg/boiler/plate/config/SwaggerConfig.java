package com.lbg.boiler.plate.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.models.info.Info;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springdoc.core.customizers.OpenApiCustomiser;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
@OpenAPIDefinition
@SecurityScheme(name = "AUTHORIZATION", type = SecuritySchemeType.APIKEY, in = SecuritySchemeIn.HEADER, paramName = "AUTHORIZATION")
public class SwaggerConfig {

    @Bean
    public OpenApiCustomiser getOpenApiCustomizer() {
        return openAPI -> openAPI
            .info(new Info().title("LBG Boiler Plate")
                .description("Microservice Accelerator Project for LBG")
                .version("1.0"));
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class ServiceTags {
        public static final String HELLO_WORLD_SERVICE = "Hello World Service";
    }

}
package com.lbg.boiler.plate.config;


import com.lbg.cross.cutting.security.filters.AuthorizationFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandlerImpl;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter.ReferrerPolicy;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
@Order(SecurityProperties.BASIC_AUTH_ORDER)
public class WebSecurityConfig {

    private final AuthorizationFilter jwtAuthorizationFilter;
    protected static final String[] ACTUATOR_WHITELIST = {
        "/actuator/**","/h2-console/**"
    };


    protected static final String[] SWAGGER_WHITELIST = {
        "/v3/api-docs/**",
        "/swagger-ui/**",
        "/swagger-ui.html", "/api-docs/**"
    };

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.authorizeRequests()
//            .antMatchers(SWAGGER_WHITELIST).permitAll()
            .anyRequest().authenticated()
            .and()
            .addFilterBefore(jwtAuthorizationFilter, UsernamePasswordAuthenticationFilter.class)
            .exceptionHandling()
            .accessDeniedHandler(getAccessDeniedHandler());

        // With JWT token application is immune to CSRF, so disabling it
        http.csrf().disable();
        http.headers()
            .xssProtection()
            .and()
            .contentSecurityPolicy("script-src 'self'")
            .and()
            .referrerPolicy(ReferrerPolicy.SAME_ORIGIN);

        //Switch off session creation
        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        return http.build();
    }

    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return web -> web.ignoring()
            .antMatchers(SWAGGER_WHITELIST)
            .antMatchers(ACTUATOR_WHITELIST);
    }

    private AccessDeniedHandlerImpl getAccessDeniedHandler() {
        AccessDeniedHandlerImpl handler = new AccessDeniedHandlerImpl();
        handler.setErrorPage(null);
        return handler;
    }
}

package com.lbg.boiler.plate.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@AllArgsConstructor
@Getter
@Builder
public class Message {

    /**
     * Name of the person for whom message is
     */
    private String personName;

}
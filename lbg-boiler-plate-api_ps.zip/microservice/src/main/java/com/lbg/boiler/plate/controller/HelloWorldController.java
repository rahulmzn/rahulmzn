package com.lbg.boiler.plate.controller;

import com.google.common.flogger.StackSize;
import com.lbg.boiler.plate.constant.ResourcePath.BoilerPlate;
import com.lbg.boiler.plate.controller.contract.HelloWorldApi;
import com.lbg.boiler.plate.model.HelloWorldResponse;
import com.lbg.boiler.plate.service.HelloWorldService;
import java.util.logging.Level;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(BoilerPlate.V1.ROOT)
@Validated
@Flogger
public class HelloWorldController implements HelloWorldApi {

    private static final String LOG_MESSAGE = "Logging {} Message";

    private final HelloWorldService helloWorldService;

    @Autowired
    public HelloWorldController(HelloWorldService helloWorldService) {
        this.helloWorldService = helloWorldService;
    }

    @Override
    @GetMapping(value = BoilerPlate.V1.SAY_HELLO, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<HelloWorldResponse> sayHello(@PathVariable String name) {
        logMessageTypes();
        log.at(Level.INFO).withStackTrace(StackSize.MEDIUM).log("Application saying hello to %s ", name);
        HelloWorldResponse response = HelloWorldResponse.builder()
            .name(helloWorldService.sayHello(name)).build();
        return ResponseEntity.ok(response);
    }

    private void logMessageTypes() {
        log.at(Level.INFO).log(LOG_MESSAGE, Level.INFO.getName());
        log.at(Level.WARNING).log(LOG_MESSAGE, Level.WARNING.getName());
        log.at(Level.SEVERE).log(LOG_MESSAGE, Level.SEVERE.getName());
        log.at(Level.FINEST).log(LOG_MESSAGE, Level.FINEST.getName());
        log.at(Level.FINE).log(LOG_MESSAGE, Level.FINE.getName());
        log.at(Level.FINER).log(LOG_MESSAGE, Level.FINER.getName());
        log.at(Level.CONFIG).log(LOG_MESSAGE, Level.CONFIG.getName());

    }
}

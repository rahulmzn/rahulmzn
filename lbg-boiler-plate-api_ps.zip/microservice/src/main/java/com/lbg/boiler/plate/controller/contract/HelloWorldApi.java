package com.lbg.boiler.plate.controller.contract;

import static com.lbg.boiler.plate.config.SwaggerConfig.ServiceTags.HELLO_WORLD_SERVICE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import com.lbg.boiler.plate.model.HelloWorldResponse;
import com.lbg.cross.cutting.exception.ErrorResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
@Tag(name = HELLO_WORLD_SERVICE)
public interface HelloWorldApi {
    @Operation(description = "Say hello", operationId = "hello", summary = "Says Hello to the name provided")
    @ApiResponse(responseCode = "201", content = {@Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = HelloWorldResponse.class))})
    @ApiResponse(responseCode = "400", description = "Bad Request",content = {@Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorResponse.class))})
    @ApiResponse(responseCode = "500",description = "Internal Server Error",content = {@Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorResponse.class))})
    ResponseEntity<HelloWorldResponse> sayHello(@PathVariable("name") String name);
}

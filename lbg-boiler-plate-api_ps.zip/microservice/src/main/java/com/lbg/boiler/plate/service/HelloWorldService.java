package com.lbg.boiler.plate.service;


public interface HelloWorldService {

    /**
     * @param message : Message for LBG
     * @return Input message
     */
    String sayHello(String message);

}


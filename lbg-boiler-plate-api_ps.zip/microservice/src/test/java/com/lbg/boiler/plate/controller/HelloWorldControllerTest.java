package com.lbg.boiler.plate.controller;

import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.boiler.plate.constant.ResourcePath.BoilerPlate;
import com.lbg.boiler.plate.service.HelloWorldService;
import com.lbg.boiler.plate.service.SayHelloWorldService;
import com.lbg.cross.cutting.exception.ErrorResponseBuilder;
import com.lbg.cross.cutting.exception.ExceptionControllerAdvice;
import com.lbg.cross.cutting.security.AuthorizationService;
import com.lbg.cross.cutting.security.model.TokenRequest;
import com.lbg.cross.cutting.security.model.TokenResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;


@ExtendWith(MockitoExtension.class)
class HelloWorldControllerTest {

    private MockMvc mockMvc;

    @InjectMocks
    private HelloWorldController helloWorldController;

    @Mock
    private HelloWorldService helloWorldService;

    @BeforeEach
    void setUp() {
        JacksonTester.initFields(this, new ObjectMapper());
        MessageSource messageSource = mock(MessageSource.class);
        // MockMvc standalone approach
        mockMvc = MockMvcBuilders.standaloneSetup(helloWorldController)
            .setControllerAdvice(new ExceptionControllerAdvice(new ErrorResponseBuilder(messageSource)))
            .build();
    }

    @Test
    @DisplayName("Should Successfully return hello LBG world message ")
    void shouldSayHello() throws Exception {
            sayHello("testing-data-1");
            sayHello("testing-data-2");
    }


    void sayHello(String name) throws Exception {
        TokenResponse tokenResponse = new TokenResponse();
        tokenResponse.setToken("toke");
        tokenResponse.setValidated(true);
        TokenRequest tokenRequest = new TokenRequest();
        tokenRequest.setTokenId("TokenId");
        tokenRequest.setJourneyType("Testing-boiler-plate");
        tokenResponse.setTokenRequest(tokenRequest);

        when(helloWorldService.sayHello(anyString())).thenReturn("Hello "+name);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(BoilerPlate.V1.ROOT+BoilerPlate.V1.SAY_HELLO,name).secure(true)
                .header(HttpHeaders.AUTHORIZATION, "Bearer token123234325254")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.name").exists())
            .andExpect(jsonPath("$.*",hasSize(1)))
            .andExpect(jsonPath("$.name").value("Hello "+name))
            .andReturn();

        String resultDOW = result.getResponse().getContentAsString();
        assertNotNull(resultDOW);
    }
}
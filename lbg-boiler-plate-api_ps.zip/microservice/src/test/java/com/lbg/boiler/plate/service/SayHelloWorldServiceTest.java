package com.lbg.boiler.plate.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SayHelloWorldServiceTest {

    @InjectMocks
    SayHelloWorldService sayHelloWorldService;

    @Test
    void sayHello() {
        String result = sayHelloWorldService.sayHello("Test-User-1");
        assertEquals("Hello Test-User-1", result);
    }
}